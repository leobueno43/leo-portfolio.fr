-- ============================================
-- SYSTÈME DE BOUTIQUE EN LIGNE
-- Pour l'association Mafia Airsoft Team
-- ============================================

-- Table des catégories de produits
CREATE TABLE IF NOT EXISTS shop_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    image_path VARCHAR(255),
    display_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_slug (slug),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des produits
CREATE TABLE IF NOT EXISTS shop_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    name VARCHAR(200) NOT NULL,
    slug VARCHAR(220) NOT NULL UNIQUE,
    description TEXT,
    featured_image VARCHAR(255),
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock_quantity INT DEFAULT 0,
    stock_management TINYINT(1) DEFAULT 1 COMMENT 'Gérer le stock (1) ou stock illimité (0)',
    is_featured TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    views INT DEFAULT 0,
    sales_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES shop_categories(id) ON DELETE SET NULL,
    INDEX idx_slug (slug),
    INDEX idx_category (category_id),
    INDEX idx_active (is_active),
    INDEX idx_featured (is_featured)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des images produits (galerie)
CREATE TABLE IF NOT EXISTS shop_product_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    display_order INT DEFAULT 0,
    is_primary TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES shop_products(id) ON DELETE CASCADE,
    INDEX idx_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des variantes de produits (tailles, couleurs)
CREATE TABLE IF NOT EXISTS shop_product_variants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    variant_name VARCHAR(100) NOT NULL COMMENT 'Ex: Taille S, Couleur Rouge, XL Bleu',
    sku VARCHAR(50) UNIQUE COMMENT 'Code produit unique',
    price_modifier DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Modification du prix (+/- par rapport au prix de base)',
    stock_quantity INT DEFAULT 0,
    is_available TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES shop_products(id) ON DELETE CASCADE,
    INDEX idx_product (product_id),
    INDEX idx_sku (sku)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table du panier
CREATE TABLE IF NOT EXISTS shop_cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    variant_id INT,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES shop_products(id) ON DELETE CASCADE,
    FOREIGN KEY (variant_id) REFERENCES shop_product_variants(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (user_id, product_id, variant_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des commandes
CREATE TABLE IF NOT EXISTS shop_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(50) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    
    -- Informations de livraison
    shipping_name VARCHAR(100) NOT NULL,
    shipping_email VARCHAR(100) NOT NULL,
    shipping_phone VARCHAR(20),
    shipping_address TEXT NOT NULL,
    shipping_city VARCHAR(100) NOT NULL,
    shipping_postal_code VARCHAR(20) NOT NULL,
    shipping_country VARCHAR(100) DEFAULT 'France',
    
    -- Montants
    subtotal DECIMAL(10,2) NOT NULL COMMENT 'Sous-total produits',
    shipping_cost DECIMAL(10,2) DEFAULT 0.00,
    tax_amount DECIMAL(10,2) DEFAULT 0.00,
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    total DECIMAL(10,2) NOT NULL,
    
    -- Paiement
    payment_method VARCHAR(50) COMMENT 'stripe, paypal, virement',
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    payment_intent_id VARCHAR(255) COMMENT 'ID Stripe/PayPal',
    paid_at TIMESTAMP NULL,
    
    -- Statut de la commande
    order_status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    tracking_number VARCHAR(100) COMMENT 'Numéro de suivi de livraison',
    
    -- Notes
    customer_notes TEXT,
    admin_notes TEXT,
    
    -- Dates
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_order_number (order_number),
    INDEX idx_user (user_id),
    INDEX idx_payment_status (payment_status),
    INDEX idx_order_status (order_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des articles de commande
CREATE TABLE IF NOT EXISTS shop_order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT,
    variant_id INT,
    product_name VARCHAR(200) NOT NULL COMMENT 'Snapshot du nom au moment de la commande',
    variant_name VARCHAR(100),
    price DECIMAL(10,2) NOT NULL COMMENT 'Prix unitaire au moment de la commande',
    quantity INT NOT NULL DEFAULT 1,
    subtotal DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES shop_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES shop_products(id) ON DELETE SET NULL,
    FOREIGN KEY (variant_id) REFERENCES shop_product_variants(id) ON DELETE SET NULL,
    INDEX idx_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insertion de catégories par défaut
INSERT INTO shop_categories (name, slug, description) VALUES
('Vêtements', 'vetements', 'T-shirts, sweats, vestes aux couleurs de l\'association'),
('Accessoires', 'accessoires', 'Casquettes, bonnets, tours de cou'),
('Patches', 'patches', 'Patches et écussons MAT'),
('Équipement', 'equipement', 'Matériel et équipement airsoft');

-- Insertion de produits exemples
INSERT INTO shop_products (category_id, name, slug, description, price, stock_quantity, is_featured) VALUES
(1, 'T-Shirt MAT Noir', 't-shirt-mat-noir', 'T-shirt noir avec logo MAT brodé. Coton 100% qualité premium.', 25.00, 50, 1),
(1, 'Sweat à Capuche MAT', 'sweat-capuche-mat', 'Sweat confortable avec capuche, logo MAT sur le devant et au dos.', 45.00, 30, 1),
(2, 'Casquette MAT', 'casquette-mat', 'Casquette ajustable avec logo MAT brodé.', 18.00, 100, 0),
(3, 'Patch MAT Velcro', 'patch-mat-velcro', 'Patch velcro officiel MAT - 8x5cm', 8.00, 200, 0);

-- Insertion de variantes exemples (tailles pour le t-shirt)
INSERT INTO shop_product_variants (product_id, variant_name, sku, stock_quantity) VALUES
(1, 'Taille S', 'TSHIRT-MAT-S', 15),
(1, 'Taille M', 'TSHIRT-MAT-M', 20),
(1, 'Taille L', 'TSHIRT-MAT-L', 10),
(1, 'Taille XL', 'TSHIRT-MAT-XL', 5);

-- Insertion de variantes pour le sweat
INSERT INTO shop_product_variants (product_id, variant_name, sku, stock_quantity) VALUES
(2, 'Taille S', 'SWEAT-MAT-S', 10),
(2, 'Taille M', 'SWEAT-MAT-M', 10),
(2, 'Taille L', 'SWEAT-MAT-L', 5),
(2, 'Taille XL', 'SWEAT-MAT-XL', 5);
