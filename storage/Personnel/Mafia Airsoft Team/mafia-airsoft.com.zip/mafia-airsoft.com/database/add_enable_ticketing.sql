-- Ajout du champ enable_ticketing à la table events
-- Ce champ permet d'activer ou désactiver la génération de billets pour chaque événement

ALTER TABLE events 
ADD COLUMN enable_ticketing TINYINT(1) DEFAULT 1 COMMENT 'Activer la billetterie pour cet événement (1 = oui, 0 = non)';
