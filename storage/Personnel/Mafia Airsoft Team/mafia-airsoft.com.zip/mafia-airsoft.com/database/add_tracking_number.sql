-- Ajouter la colonne tracking_number à la table shop_orders
ALTER TABLE shop_orders 
ADD COLUMN tracking_number VARCHAR(100) COMMENT 'Numéro de suivi de livraison' 
AFTER order_status;
