-- ============================================
-- BASE DE DONNÉES COMPLÈTE
-- Association Mafia Airsoft Team
-- ============================================

-- Création de la base de données
CREATE DATABASE IF NOT EXISTS zelu6269_airsoft_association CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE zelu6269_airsoft_association;

-- ============================================
-- TABLES PRINCIPALES
-- ============================================

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pseudo VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    is_admin TINYINT(1) DEFAULT 0,
    phone VARCHAR(20),
    profile_picture VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_pseudo (pseudo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des événements/parties
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    scenario TEXT,
    event_date DATETIME NOT NULL,
    location VARCHAR(200) NOT NULL,
    equipment_required TEXT,
    rules TEXT,
    is_active TINYINT(1) DEFAULT 1,
    registration_open TINYINT(1) DEFAULT 1,
    enable_ticketing TINYINT(1) DEFAULT 1 COMMENT 'Activer la billetterie pour cet événement',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_event_date (event_date),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des équipes personnalisées par événement
CREATE TABLE IF NOT EXISTS event_teams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    team_key VARCHAR(50) NOT NULL,
    team_name VARCHAR(100) NOT NULL,
    team_color VARCHAR(7) NOT NULL,
    max_players INT DEFAULT 0,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    UNIQUE KEY unique_team_per_event (event_id, team_key),
    INDEX idx_event_id (event_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des inscriptions
CREATE TABLE IF NOT EXISTS registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    event_id INT NOT NULL,
    team VARCHAR(50) NOT NULL,
    notes TEXT,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    UNIQUE KEY unique_registration (user_id, event_id),
    INDEX idx_event_team (event_id, team),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- SYSTÈME DE BILLETTERIE
-- ============================================

-- Table pour les billets d'événements
CREATE TABLE IF NOT EXISTS event_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    ticket_code VARCHAR(100) UNIQUE NOT NULL,
    qr_code_path VARCHAR(255),
    pdf_path VARCHAR(255),
    is_scanned TINYINT(1) DEFAULT 0,
    scanned_at DATETIME NULL,
    scanned_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (scanned_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_event_id (event_id),
    INDEX idx_user_id (user_id),
    INDEX idx_ticket_code (ticket_code),
    INDEX idx_is_scanned (is_scanned)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Vue pour les statistiques des billets par événement
CREATE OR REPLACE VIEW ticket_statistics AS
SELECT 
    e.id as event_id,
    e.title as event_title,
    COUNT(et.id) as total_tickets,
    SUM(CASE WHEN et.is_scanned = 1 THEN 1 ELSE 0 END) as scanned_tickets,
    SUM(CASE WHEN et.is_scanned = 0 THEN 1 ELSE 0 END) as pending_tickets,
    ROUND(SUM(CASE WHEN et.is_scanned = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(et.id), 2) as attendance_rate
FROM events e
LEFT JOIN event_tickets et ON e.id = et.event_id
GROUP BY e.id, e.title;

-- ============================================
-- SYSTÈME DE BLOG
-- ============================================

-- Table des articles de blog
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(220) NOT NULL UNIQUE,
    content TEXT NOT NULL,
    excerpt TEXT,
    featured_image VARCHAR(255),
    author_id INT NOT NULL,
    is_published TINYINT(1) DEFAULT 0,
    published_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    views INT DEFAULT 0,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_slug (slug),
    INDEX idx_published (is_published),
    INDEX idx_published_at (published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table de la galerie d'images des articles de blog
CREATE TABLE IF NOT EXISTS blog_gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    blog_post_id INT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    caption TEXT,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (blog_post_id) REFERENCES blog_posts(id) ON DELETE CASCADE,
    INDEX idx_blog_post (blog_post_id),
    INDEX idx_display_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- GALERIE DE LA PAGE D'ACCUEIL
-- ============================================

-- Table pour gérer la galerie photo de la page d'accueil
CREATE TABLE IF NOT EXISTS gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_path VARCHAR(255) NOT NULL,
    title VARCHAR(255) DEFAULT NULL,
    description TEXT DEFAULT NULL,
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_active_order (is_active, display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- SYSTÈME DE BOUTIQUE EN LIGNE
-- ============================================

-- Table des catégories de produits
CREATE TABLE IF NOT EXISTS shop_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    image_path VARCHAR(255),
    display_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_slug (slug),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des produits
CREATE TABLE IF NOT EXISTS shop_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    name VARCHAR(200) NOT NULL,
    slug VARCHAR(220) NOT NULL UNIQUE,
    description TEXT,
    featured_image VARCHAR(255),
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock_quantity INT DEFAULT 0,
    stock_management TINYINT(1) DEFAULT 1 COMMENT 'Gérer le stock (1) ou stock illimité (0)',
    is_featured TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    views INT DEFAULT 0,
    sales_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES shop_categories(id) ON DELETE SET NULL,
    INDEX idx_slug (slug),
    INDEX idx_category (category_id),
    INDEX idx_active (is_active),
    INDEX idx_featured (is_featured)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des images produits (galerie)
CREATE TABLE IF NOT EXISTS shop_product_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    display_order INT DEFAULT 0,
    is_primary TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES shop_products(id) ON DELETE CASCADE,
    INDEX idx_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des variantes de produits (tailles, couleurs)
CREATE TABLE IF NOT EXISTS shop_product_variants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    variant_name VARCHAR(100) NOT NULL COMMENT 'Ex: Taille S, Couleur Rouge, XL Bleu',
    sku VARCHAR(50) UNIQUE COMMENT 'Code produit unique',
    price_modifier DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Modification du prix (+/- par rapport au prix de base)',
    stock_quantity INT DEFAULT 0,
    is_available TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES shop_products(id) ON DELETE CASCADE,
    INDEX idx_product (product_id),
    INDEX idx_sku (sku)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table du panier
CREATE TABLE IF NOT EXISTS shop_cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    variant_id INT,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES shop_products(id) ON DELETE CASCADE,
    FOREIGN KEY (variant_id) REFERENCES shop_product_variants(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (user_id, product_id, variant_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des commandes
CREATE TABLE IF NOT EXISTS shop_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(50) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    
    -- Informations de livraison
    shipping_name VARCHAR(100) NOT NULL,
    shipping_email VARCHAR(100) NOT NULL,
    shipping_phone VARCHAR(20),
    shipping_address TEXT NOT NULL,
    shipping_city VARCHAR(100) NOT NULL,
    shipping_postal_code VARCHAR(20) NOT NULL,
    shipping_country VARCHAR(100) DEFAULT 'France',
    
    -- Montants
    subtotal DECIMAL(10,2) NOT NULL COMMENT 'Sous-total produits',
    shipping_cost DECIMAL(10,2) DEFAULT 0.00,
    tax_amount DECIMAL(10,2) DEFAULT 0.00,
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    total DECIMAL(10,2) NOT NULL,
    
    -- Paiement
    payment_method VARCHAR(50) COMMENT 'stripe, paypal, virement',
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    payment_intent_id VARCHAR(255) COMMENT 'ID Stripe/PayPal',
    paid_at TIMESTAMP NULL,
    
    -- Statut de la commande
    order_status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    tracking_number VARCHAR(100) COMMENT 'Numéro de suivi de livraison',
    
    -- Notes
    customer_notes TEXT,
    admin_notes TEXT,
    
    -- Dates
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_order_number (order_number),
    INDEX idx_user (user_id),
    INDEX idx_payment_status (payment_status),
    INDEX idx_order_status (order_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table des articles de commande
CREATE TABLE IF NOT EXISTS shop_order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT,
    variant_id INT,
    product_name VARCHAR(200) NOT NULL COMMENT 'Snapshot du nom au moment de la commande',
    variant_name VARCHAR(100),
    price DECIMAL(10,2) NOT NULL COMMENT 'Prix unitaire au moment de la commande',
    quantity INT NOT NULL DEFAULT 1,
    subtotal DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES shop_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES shop_products(id) ON DELETE SET NULL,
    FOREIGN KEY (variant_id) REFERENCES shop_product_variants(id) ON DELETE SET NULL,
    INDEX idx_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- DONNÉES D'EXEMPLE
-- ============================================

-- Insertion d'un compte admin par défaut (mot de passe: admin123)
INSERT INTO users (pseudo, email, password_hash, is_admin) 
VALUES ('admin', 'admin@airsoft.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1)
ON DUPLICATE KEY UPDATE id=id;

-- Insertion d'exemples de parties
INSERT INTO events (title, description, scenario, event_date, location, enable_ticketing)
VALUES 
('Opération Aiguille Noire', 
 'Mission de reconnaissance et d\'infiltration en milieu urbain',
 'Les forces BLEUES doivent infiltrer la base ROUGE et récupérer des documents classifiés. Les ROUGES doivent défendre leur QG et protéger les objectifs.',
 '2025-12-15 09:00:00',
 'Terrain de jeu - Forêt de Fontainebleau',
 1),
 
('Défense du Fort', 
 'Scénario de défense tactique avec objectifs multiples',
 'L\'équipe ROUGE défend une position fortifiée avec des ressources limitées. L\'équipe BLEUE doit capturer plusieurs points stratégiques avant la fin du temps imparti.',
 '2025-12-22 10:00:00',
 'Fort abandonné - Seine-et-Marne',
 1)
ON DUPLICATE KEY UPDATE id=id;

-- Créer les équipes par défaut pour les événements
INSERT INTO event_teams (event_id, team_key, team_name, team_color, max_players, display_order)
SELECT id, 'BLUE', 'Équipe Bleue', '#3b82f6', 15, 1 FROM events
WHERE NOT EXISTS (SELECT 1 FROM event_teams WHERE event_id = events.id AND team_key = 'BLUE');

INSERT INTO event_teams (event_id, team_key, team_name, team_color, max_players, display_order)
SELECT id, 'RED', 'Équipe Rouge', '#dc2626', 15, 2 FROM events
WHERE NOT EXISTS (SELECT 1 FROM event_teams WHERE event_id = events.id AND team_key = 'RED');

INSERT INTO event_teams (event_id, team_key, team_name, team_color, max_players, display_order)
SELECT id, 'ORGA', 'Organisation', '#a3a3a3', 3, 3 FROM events
WHERE NOT EXISTS (SELECT 1 FROM event_teams WHERE event_id = events.id AND team_key = 'ORGA');

-- Insertion d'articles de blog exemples
INSERT INTO blog_posts (title, slug, content, excerpt, author_id, is_published, published_at)
VALUES 
('Bienvenue sur le blog M.A.T', 
 'bienvenue-sur-le-blog-mat',
 'Bienvenue sur le blog officiel de Mission Airsoft Tactique ! Ici, vous trouverez tous les comptes-rendus de nos parties, des conseils pour améliorer votre jeu, et toutes les actualités de l\'association.\n\nNous publierons régulièrement :\n- Les comptes-rendus des parties passées avec photos\n- Des conseils tactiques et techniques\n- Les annonces des événements à venir\n- Des interviews de joueurs\n- Des tests de matériel\n\nRestez connectés pour ne rien manquer de nos aventures sur le terrain !',
 'Découvrez le blog officiel de M.A.T avec comptes-rendus, conseils et actualités airsoft.',
 1,
 1,
 NOW()),
 
('Compte-rendu : Opération Aiguille Noire', 
 'compte-rendu-operation-aiguille-noire',
 'Ce dimanche avait lieu notre première grande opération de l\'année : Opération Aiguille Noire.\n\n15 joueurs de l\'équipe BLEUE et 15 de l\'équipe ROUGE se sont affrontés dans un scénario d\'infiltration intense. L\'équipe BLEUE devait récupérer des documents classifiés dans la base ROUGE.\n\nLe match a été très serré avec plusieurs retournements de situation. Félicitations à l\'équipe BLEUE qui a réussi sa mission après 3 heures de jeu intense !\n\nPoints positifs :\n- Excellent esprit d\'équipe\n- Fair-play exemplaire\n- Météo idéale\n\nOn se retrouve le mois prochain pour l\'Opération Défense du Fort !',
 'Retour sur une partie intense avec 30 joueurs dans la forêt de Fontainebleau.',
 1,
 1,
 DATE_SUB(NOW(), INTERVAL 2 DAY))
ON DUPLICATE KEY UPDATE id=id;

-- Insertion de catégories de produits
INSERT INTO shop_categories (name, slug, description) VALUES
('Vêtements', 'vetements', 'T-shirts, sweats, vestes aux couleurs de l\'association'),
('Accessoires', 'accessoires', 'Casquettes, bonnets, tours de cou'),
('Patches', 'patches', 'Patches et écussons MAT'),
('Équipement', 'equipement', 'Matériel et équipement airsoft')
ON DUPLICATE KEY UPDATE id=id;

-- Insertion de produits exemples
INSERT INTO shop_products (category_id, name, slug, description, price, stock_quantity, is_featured) VALUES
(1, 'T-Shirt MAT Noir', 't-shirt-mat-noir', 'T-shirt noir avec logo MAT brodé. Coton 100% qualité premium.', 25.00, 50, 1),
(1, 'Sweat à Capuche MAT', 'sweat-capuche-mat', 'Sweat confortable avec capuche, logo MAT sur le devant et au dos.', 45.00, 30, 1),
(2, 'Casquette MAT', 'casquette-mat', 'Casquette ajustable avec logo MAT brodé.', 18.00, 100, 0),
(3, 'Patch MAT Velcro', 'patch-mat-velcro', 'Patch velcro officiel MAT - 8x5cm', 8.00, 200, 0)
ON DUPLICATE KEY UPDATE id=id;

-- Insertion de variantes exemples (tailles pour le t-shirt)
INSERT INTO shop_product_variants (product_id, variant_name, sku, stock_quantity) VALUES
(1, 'Taille S', 'TSHIRT-MAT-S', 15),
(1, 'Taille M', 'TSHIRT-MAT-M', 20),
(1, 'Taille L', 'TSHIRT-MAT-L', 10),
(1, 'Taille XL', 'TSHIRT-MAT-XL', 5)
ON DUPLICATE KEY UPDATE id=id;

-- Insertion de variantes pour le sweat
INSERT INTO shop_product_variants (product_id, variant_name, sku, stock_quantity) VALUES
(2, 'Taille S', 'SWEAT-MAT-S', 10),
(2, 'Taille M', 'SWEAT-MAT-M', 10),
(2, 'Taille L', 'SWEAT-MAT-L', 5),
(2, 'Taille XL', 'SWEAT-MAT-XL', 5)
ON DUPLICATE KEY UPDATE id=id;

-- ============================================
-- Message de confirmation
-- ============================================
SELECT 'Base de données créée avec succès !' as Message;
SELECT 'Toutes les tables et données d\'exemple ont été importées.' as Info;
