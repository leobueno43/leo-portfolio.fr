<?php
require_once 'config/database.php';
require_once 'config/session.php';

// Filtres
$category_filter = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? 'newest';

// Récupérer les catégories
$categories = $pdo->query("SELECT * FROM shop_categories WHERE is_active = 1 ORDER BY name ASC")->fetchAll();

// Construire la requête de produits
$where = ["p.is_active = 1"];
$params = [];

if ($category_filter) {
    $where[] = "c.slug = ?";
    $params[] = $category_filter;
}

if ($search) {
    $where[] = "(p.name LIKE ? OR p.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$where_clause = implode(' AND ', $where);

// Ordre de tri
$order_by = match($sort) {
    'price_asc' => 'p.price ASC',
    'price_desc' => 'p.price DESC',
    'name' => 'p.name ASC',
    'popular' => 'p.sales_count DESC',
    default => 'p.created_at DESC'
};

$stmt = $pdo->prepare("
    SELECT p.*, c.name as category_name, c.slug as category_slug
    FROM shop_products p
    LEFT JOIN shop_categories c ON p.category_id = c.id
    WHERE $where_clause
    ORDER BY $order_by
");
$stmt->execute($params);
$products = $stmt->fetchAll();

// Récupérer les produits en vedette
$featured = $pdo->query("
    SELECT p.*, c.name as category_name 
    FROM shop_products p 
    LEFT JOIN shop_categories c ON p.category_id = c.id 
    WHERE p.is_active = 1 AND p.is_featured = 1 
    ORDER BY p.sales_count DESC 
    LIMIT 4
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boutique MAT - Mafia Airsoft Team</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/shop.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="container page-content">
        <!-- Bannière boutique -->
        <section class="shop-hero">
            <h1><?= icon('shopping-bag') ?> Boutique Officielle Mafia Airsoft Team</h1>
            <p>Vêtements et accessoires aux couleurs de l'association</p>
        </section>

        <!-- Produits en vedette -->
        <?php if (!empty($featured) && !$search && !$category_filter): ?>
        <section class="featured-products">
            <h2>⭐ Produits en vedette</h2>
            <div class="products-grid">
                <?php foreach ($featured as $product): ?>
                    <div class="product-card featured">
                        <a href="product.php?id=<?= $product['id'] ?>" class="product-link">
                            <?php if ($product['featured_image']): ?>
                                <img src="<?= htmlspecialchars($product['featured_image']) ?>" 
                                     alt="<?= htmlspecialchars($product['name']) ?>" 
                                     class="product-image">
                            <?php else: ?>
                                <div class="product-image-placeholder">
                                    <?= icon('image') ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="product-info">
                                <span class="product-category"><?= htmlspecialchars($product['category_name'] ?? 'Produit') ?></span>
                                <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>
                                <p class="product-price"><?= number_format($product['price'], 2) ?> €</p>
                                
                                <?php if ($product['stock_management']): ?>
                                    <?php if ($product['stock_quantity'] > 0): ?>
                                        <span class="stock-badge in-stock">En stock</span>
                                    <?php else: ?>
                                        <span class="stock-badge out-of-stock">Rupture</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>

        <!-- Filtres et recherche -->
        <section class="shop-filters">
            <form method="GET" class="filters-form">
                <div class="filter-group">
                    <select name="category" onchange="this.form.submit()">
                        <option value="">Toutes les catégories</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['slug'] ?>" <?= $category_filter === $cat['slug'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-group">
                    <input type="search" name="search" placeholder="Rechercher un produit..." 
                           value="<?= htmlspecialchars($search) ?>">
                </div>

                <div class="filter-group">
                    <select name="sort" onchange="this.form.submit()">
                        <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Plus récents</option>
                        <option value="popular" <?= $sort === 'popular' ? 'selected' : '' ?>>Plus populaires</option>
                        <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Prix croissant</option>
                        <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Prix décroissant</option>
                        <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Nom A-Z</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Filtrer</button>
                <?php if ($search || $category_filter): ?>
                    <a href="shop.php" class="btn btn-secondary">Réinitialiser</a>
                <?php endif; ?>
            </form>
        </section>

        <!-- Liste des produits -->
        <section class="shop-products">
            <h2>Tous les produits (<?= count($products) ?>)</h2>
            
            <?php if (empty($products)): ?>
                <p class="no-products">Aucun produit trouvé.</p>
            <?php else: ?>
                <div class="products-grid">
                    <?php foreach ($products as $product): ?>
                        <div class="product-card">
                            <a href="product.php?id=<?= $product['id'] ?>" class="product-link">
                                <?php if ($product['featured_image']): ?>
                                    <img src="<?= htmlspecialchars($product['featured_image']) ?>" 
                                         alt="<?= htmlspecialchars($product['name']) ?>" 
                                         class="product-image">
                                <?php else: ?>
                                    <div class="product-image-placeholder">
                                        <?= icon('image') ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="product-info">
                                    <span class="product-category"><?= htmlspecialchars($product['category_name'] ?? 'Produit') ?></span>
                                    <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>
                                    <p class="product-price"><?= number_format($product['price'], 2) ?> €</p>
                                    
                                    <?php if ($product['stock_management']): ?>
                                        <?php if ($product['stock_quantity'] > 0): ?>
                                            <span class="stock-badge in-stock">En stock</span>
                                        <?php elseif ($product['stock_quantity'] <= 5): ?>
                                            <span class="stock-badge low-stock">Stock faible</span>
                                        <?php else: ?>
                                            <span class="stock-badge out-of-stock">Rupture</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
