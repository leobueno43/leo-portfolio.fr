<?php
require_once 'config/database.php';
require_once 'config/session.php';

$order_number = $_GET['order'] ?? '';

if (empty($order_number)) {
    header('Location: shop.php');
    exit;
}

// Récupérer la commande
$stmt = $pdo->prepare("
    SELECT o.*, u.email, u.pseudo
    FROM shop_orders o
    JOIN users u ON o.user_id = u.id
    WHERE o.order_number = ?
");
$stmt->execute([$order_number]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: shop.php');
    exit;
}

// Récupérer les articles de la commande
$stmt = $pdo->prepare("
    SELECT oi.*, p.name as product_name, v.variant_name
    FROM shop_order_items oi
    JOIN shop_products p ON oi.product_id = p.id
    LEFT JOIN shop_product_variants v ON oi.variant_id = v.id
    WHERE oi.order_id = ?
");
$stmt->execute([$order['id']]);
$items = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commande confirmée - Boutique MAT</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/shop.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="container page-content">
        <div class="order-success">
            <div class="success-icon">✓</div>
            <h1>Commande confirmée !</h1>
            <p class="order-number">Numéro de commande : <strong><?= htmlspecialchars($order_number) ?></strong></p>
            
            <div class="success-message">
                <p>Merci pour votre commande ! Un email de confirmation a été envoyé à <strong><?= htmlspecialchars($order['email']) ?></strong>.</p>
                <p>Vous pouvez suivre l'état de votre commande dans votre espace personnel.</p>
            </div>

            <div class="order-details">
                <h2>Détails de la commande</h2>
                
                <div class="order-info-grid">
                    <div class="info-block">
                        <h3>Adresse de livraison</h3>
                        <p>
                            <?= htmlspecialchars($order['shipping_address']) ?><br>
                            <?= htmlspecialchars($order['shipping_postal_code']) ?> <?= htmlspecialchars($order['shipping_city']) ?><br>
                            <?= htmlspecialchars($order['shipping_country']) ?>
                        </p>
                    </div>

                    <div class="info-block">
                        <h3>Paiement</h3>
                        <p>
                            Méthode : PayPal<br>
                            Statut : <?= $order['payment_status'] === 'paid' ? 'Payé' : 'En attente' ?>
                        </p>
                    </div>
                </div>

                <h3>Articles commandés</h3>
                <table class="order-items-table">
                    <thead>
                        <tr>
                            <th>Produit</th>
                            <th>Prix unitaire</th>
                            <th>Quantité</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td>
                                    <?= htmlspecialchars($item['product_name']) ?>
                                    <?php if ($item['variant_name']): ?>
                                        <br><small><?= htmlspecialchars($item['variant_name']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?= number_format($item['price'], 2) ?> €</td>
                                <td><?= $item['quantity'] ?></td>
                                <td><?= number_format($item['subtotal'], 2) ?> €</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3">Sous-total</td>
                            <td><?= number_format($order['subtotal'], 2) ?> €</td>
                        </tr>
                        <tr>
                            <td colspan="3">Livraison</td>
                            <td><?= number_format($order['shipping_cost'], 2) ?> €</td>
                        </tr>
                        <tr class="total-row">
                            <td colspan="3"><strong>Total</strong></td>
                            <td><strong><?= number_format($order['total'], 2) ?> €</strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="order-actions">
                <a href="orders.php" class="btn btn-primary">Voir mes commandes</a>
                <a href="shop.php" class="btn btn-secondary">Retour à la boutique</a>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
