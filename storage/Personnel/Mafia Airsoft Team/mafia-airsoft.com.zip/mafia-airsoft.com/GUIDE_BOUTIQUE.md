# Guide d'Installation et Configuration de la Boutique en Ligne

## 📦 Système E-Commerce MAT

Le système de boutique en ligne permet de vendre des produits aux couleurs de l'association : vêtements, accessoires, patches, équipements. Paiement sécurisé via PayPal.

---

## 🔧 Installation Complète

### Étape 1 : Base de données

Importer le fichier SQL pour créer toutes les tables :

```bash
mysql -u root -p mafia_airsoft_db < database/shop_system.sql
```

Ou depuis phpMyAdmin :
1. Ouvrir phpMyAdmin
2. Sélectionner la base `mafia_airsoft_db`
3. Onglet "Importer"
4. Choisir le fichier `database/shop_system.sql`
5. Cliquer sur "Exécuter"

**Tables créées** :
- `shop_categories` : Catégories de produits
- `shop_products` : Produits
- `shop_product_images` : Images des produits (galerie)
- `shop_product_variants` : Variantes (tailles, couleurs)
- `shop_cart` : Paniers des utilisateurs
- `shop_orders` : Commandes
- `shop_order_items` : Articles des commandes

### Étape 2 : Navigation

Un lien "Boutique" a été automatiquement ajouté au menu de navigation principal dans `includes/header.php`. Il apparaît pour tous les utilisateurs non-admin.

### Étape 3 : Configuration PayPal (optionnel)

Pour activer les paiements PayPal :

1. **Créer un compte PayPal Business** : https://www.paypal.com/fr/business
2. **Obtenir les clés API** :
   - Se connecter à https://developer.paypal.com
   - Créer une application
   - Récupérer Client ID et Secret

3. **Installer le SDK PayPal** (si composer est disponible) :
```bash
composer require paypal/rest-api-sdk-php
```

4. **Créer le fichier de configuration** `config/paypal.php` :
```php
<?php
require_once __DIR__ . '/../vendor/autoload.php';

use PayPal\Rest\ApiContext;
use PayPal\Auth\OAuthTokenCredential;

// Configuration PayPal
$clientId = 'VOTRE_CLIENT_ID';
$clientSecret = 'VOTRE_CLIENT_SECRET';

// Contexte API
$apiContext = new ApiContext(
    new OAuthTokenCredential($clientId, $clientSecret)
);

// Mode sandbox pour les tests, production pour le live
$apiContext->setConfig([
    'mode' => 'sandbox', // Changer en 'live' pour la production
    'log.LogEnabled' => true,
    'log.FileName' => __DIR__ . '/../logs/PayPal.log',
    'log.LogLevel' => 'INFO'
]);

return $apiContext;
```

### Étape 4 : Permissions Admin

Pour accéder à la gestion de la boutique, l'utilisateur doit avoir le rôle `admin`.

**Donner les droits admin à un utilisateur** :
```sql
UPDATE users SET role = 'admin' WHERE email = 'votre@email.com';
```

---

## 📁 Structure des Fichiers

### Pages Publiques

- **shop.php** : Catalogue des produits avec filtres et recherche
- **product.php** : Détail d'un produit avec galerie et variantes
- **cart.php** : Panier d'achat avec gestion des quantités
- **checkout.php** : Formulaire de paiement et validation commande
- **order_success.php** : Confirmation de commande
- **orders.php** : Historique des commandes utilisateur

### Administration

- **admin/manage_shop.php** : CRUD complet des produits
- **admin/manage_orders.php** : Gestion des commandes (statuts, suivi)

### Base de Données

- **database/shop_system.sql** : Schema complet + données d'exemple

### Styles

- **css/shop.css** : Styles dédiés à la boutique (responsive)

---

## 🛒 Fonctionnalités

### Catalogue Produits (shop.php)

- ✅ Grille de produits responsive
- ✅ Filtres par catégorie
- ✅ Recherche par nom/description
- ✅ Tri : plus récent, populaire, prix croissant/décroissant, nom
- ✅ Produits en vedette (section spéciale)
- ✅ Badges de stock (en stock, stock faible, rupture)
- ✅ Images avec placeholder si manquante

### Détail Produit (product.php)

- ✅ Galerie d'images avec miniatures cliquables
- ✅ Sélecteur de variantes (tailles, couleurs)
- ✅ Mise à jour du stock en temps réel selon variante
- ✅ Quantité ajustable
- ✅ Description complète du produit
- ✅ Référence SKU
- ✅ Breadcrumb navigation
- ✅ Ajout au panier (session ou BDD selon connexion)

### Panier (cart.php)

- ✅ Liste des articles avec images
- ✅ Modification des quantités
- ✅ Suppression d'articles
- ✅ Calcul sous-total + frais de livraison
- ✅ Livraison gratuite à partir de 50€
- ✅ Vérification du stock disponible
- ✅ Alerte si stock insuffisant
- ✅ Vider le panier
- ✅ Panier persistant en session (non connecté) ou BDD (connecté)

### Checkout (checkout.php)

- ✅ Formulaire d'adresse de livraison
- ✅ Récapitulatif de commande
- ✅ Calcul des frais de port
- ✅ Validation des données
- ✅ Création de commande en base
- ✅ Décrémentation automatique du stock
- ✅ Génération d'un numéro de commande unique
- ✅ Redirection PayPal (à configurer)

### Historique Commandes (orders.php)

- ✅ Liste de toutes les commandes utilisateur
- ✅ Statuts : en attente, en traitement, expédiée, livrée, annulée
- ✅ Détail complet d'une commande
- ✅ Suivi de livraison (tracking number)
- ✅ Articles commandés avec images

### Administration Produits (admin/manage_shop.php)

- ✅ Liste de tous les produits avec aperçu
- ✅ Créer un nouveau produit
- ✅ Modifier un produit existant
- ✅ Supprimer un produit
- ✅ Upload d'image principale
- ✅ Gestion des variantes (ajouter/supprimer tailles, couleurs)
- ✅ Catégories assignables
- ✅ Gestion du stock par produit ou variante
- ✅ Produit en vedette (featured)
- ✅ Activer/désactiver un produit

### Administration Commandes (admin/manage_orders.php)

- ✅ Dashboard avec statistiques (total, en attente, expédiées, revenus)
- ✅ Liste de toutes les commandes
- ✅ Filtres par statut
- ✅ Recherche par numéro, client, email
- ✅ Modifier le statut d'une commande
- ✅ Ajouter un numéro de suivi
- ✅ Vue détaillée de chaque commande

---

## 💳 Processus de Commande

### Utilisateur Non Connecté

1. Navigation sur `shop.php`
2. Ajout de produits au panier → stocké en **session PHP**
3. Accès au panier `cart.php`
4. Clic sur "Procéder au paiement" → **redirection vers login.php**
5. Après connexion → retour automatique au checkout

### Utilisateur Connecté

1. Navigation sur `shop.php`
2. Ajout de produits au panier → stocké en **base de données** (`shop_cart`)
3. Accès au panier `cart.php`
4. Clic sur "Procéder au paiement" → accès à `checkout.php`
5. Remplissage du formulaire de livraison
6. Validation → création de commande dans `shop_orders`
7. Ajout des articles dans `shop_order_items`
8. Décrémentation du stock
9. Vidage du panier
10. Redirection vers `order_success.php`

**Note** : Le paiement PayPal est actuellement simulé. Pour activer PayPal, suivre l'étape 3 de l'installation.

---

## 🔒 Gestion du Stock

### Stock Global (Produit)

Si le produit n'a **pas de variantes**, le stock est géré au niveau du produit :
- Colonne `shop_products.stock_quantity`
- Décrémenté automatiquement lors d'une commande

### Stock par Variante

Si le produit a **des variantes** (ex: T-shirt S, M, L), le stock est géré par variante :
- Colonne `shop_product_variants.stock_quantity`
- Chaque taille/couleur a son propre stock
- Décrémenté automatiquement lors d'une commande

### Désactiver la Gestion du Stock

Cocher la case "Activer la gestion du stock" dans `admin/manage_shop.php` :
- Si décoché (`stock_management = 0`) → pas de vérification de stock
- Utile pour les produits numériques ou services

---

## 🎨 Personnalisation du Design

Les styles sont dans **css/shop.css**. Variables CSS disponibles :

```css
--primary: #dc2626;           /* Rouge principal */
--secondary: #1a1a1a;         /* Noir secondaire */
--success: #22c55e;           /* Vert succès */
--danger: #dc2626;            /* Rouge danger */
--warning: #f59e0b;           /* Orange warning */
--tactical-surface: #1a1a1a;  /* Fond des cartes */
--tactical-border: #2a2a2a;   /* Bordures */
```

**Modifier les couleurs** : Éditer les variables dans `css/style.css` (lignes 6-30).

**Responsive** : Le design s'adapte automatiquement à tous les écrans (desktop, tablette, mobile).

---

## 📧 Notifications Email (TODO)

Pour activer les emails de confirmation :

1. Créer `config/email.php` :
```php
<?php
use PHPMailer\PHPMailer\PHPMailer;

function sendOrderConfirmation($order_id) {
    // Configuration PHPMailer (déjà présent pour les tickets)
    // Adapter pour les commandes
}
```

2. Appeler dans `checkout.php` après création de commande :
```php
sendOrderConfirmation($order_id);
```

---

## 🚀 Mise en Production

### Checklist Avant Déploiement

- [ ] Importer `database/shop_system.sql` sur le serveur de production
- [ ] Configurer PayPal en mode **live** (pas sandbox)
- [ ] Créer les catégories de produits
- [ ] Ajouter les produits avec images
- [ ] Tester le parcours complet : ajout panier → checkout → commande
- [ ] Configurer les emails de confirmation
- [ ] Définir les frais de livraison (actuellement 5.90€, gratuit à partir de 50€)
- [ ] Ajouter les conditions générales de vente (CGV)

### Sécurité

- ✅ Tous les inputs sont filtrés avec `htmlspecialchars()`
- ✅ Requêtes SQL préparées avec PDO (protection injection SQL)
- ✅ Vérification du stock avant validation
- ✅ Sessions sécurisées pour les paniers
- ✅ Validation des quantités (min 1, max selon stock)

---

## 🆘 Dépannage

### Le panier ne se vide pas

Vérifier que la session est démarrée dans `config/session.php`.

### Les images ne s'affichent pas

Vérifier les permissions du dossier `uploads/` :
```bash
chmod -R 755 uploads/
```

### Stock non décrémenté

Vérifier que `stock_management = 1` pour le produit et que la transaction SQL s'exécute correctement.

### PayPal ne fonctionne pas

1. Vérifier que le SDK est installé
2. Vérifier les clés API dans `config/paypal.php`
3. Vérifier le mode (sandbox vs live)
4. Consulter les logs dans `logs/PayPal.log`

### Commandes non créées

Vérifier les logs d'erreur PHP et les transactions PDO. S'assurer que toutes les tables existent.

---

## 📊 Données d'Exemple

Le fichier `database/shop_system.sql` contient déjà des données d'exemple :

**Catégories** :
- Vêtements
- Accessoires
- Patches
- Équipement

**Produits** :
- T-Shirt MAT (variantes : S, M, L, XL, XXL)
- Sweat MAT (variantes : S, M, L, XL)
- Casquette MAT
- Patch brodé MAT

Vous pouvez les modifier ou supprimer depuis l'interface admin.

---

## 📞 Support

Pour toute question ou problème, consulter :
- README.md principal
- Documentation PayPal : https://developer.paypal.com/docs
- PHPMailer (pour les emails) : https://github.com/PHPMailer/PHPMailer

---

## 🎯 Roadmap Future

- [ ] Codes promo et réductions
- [ ] Wishlist (liste de souhaits)
- [ ] Avis clients sur les produits
- [ ] Export des commandes en CSV/PDF
- [ ] Statistiques de vente avancées
- [ ] Multi-devises
- [ ] Intégration avec d'autres moyens de paiement (Stripe, CB)
- [ ] Notifications push pour les nouvelles commandes
- [ ] Gestion des retours/remboursements

---

**🛒 La boutique en ligne MAT est maintenant prête à l'emploi !**
