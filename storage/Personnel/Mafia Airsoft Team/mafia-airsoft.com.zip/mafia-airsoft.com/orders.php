<?php
require_once 'config/database.php';
require_once 'config/session.php';

// Vérifier que l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Récupérer les commandes de l'utilisateur
$stmt = $pdo->prepare("
    SELECT * FROM shop_orders 
    WHERE user_id = ? 
    ORDER BY created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();

// Récupérer les détails d'une commande spécifique
$order_detail = null;
$order_items = [];

if (isset($_GET['view'])) {
    $order_id = $_GET['view'];
    
    $stmt = $pdo->prepare("SELECT * FROM shop_orders WHERE id = ? AND user_id = ?");
    $stmt->execute([$order_id, $_SESSION['user_id']]);
    $order_detail = $stmt->fetch();
    
    if ($order_detail) {
        $stmt = $pdo->prepare("
            SELECT oi.*, p.name as product_name, p.featured_image, v.variant_name
            FROM shop_order_items oi
            JOIN shop_products p ON oi.product_id = p.id
            LEFT JOIN shop_product_variants v ON oi.variant_id = v.id
            WHERE oi.order_id = ?
        ");
        $stmt->execute([$order_id]);
        $order_items = $stmt->fetchAll();
    }
}

// Fonction pour obtenir le badge de statut
function getStatusBadge($status) {
    $badges = [
        'pending' => ['label' => 'En attente', 'class' => 'badge-warning'],
        'processing' => ['label' => 'En traitement', 'class' => 'badge-info'],
        'shipped' => ['label' => 'Expédiée', 'class' => 'badge-primary'],
        'delivered' => ['label' => 'Livrée', 'class' => 'badge-success'],
        'cancelled' => ['label' => 'Annulée', 'class' => 'badge-danger']
    ];
    
    $badge = $badges[$status] ?? ['label' => $status, 'class' => 'badge-secondary'];
    return '<span class="badge ' . $badge['class'] . '">' . $badge['label'] . '</span>';
}

function getPaymentStatusBadge($status) {
    $badges = [
        'pending' => ['label' => 'En attente', 'class' => 'badge-warning'],
        'paid' => ['label' => 'Payé', 'class' => 'badge-success'],
        'failed' => ['label' => 'Échoué', 'class' => 'badge-danger'],
        'refunded' => ['label' => 'Remboursé', 'class' => 'badge-info']
    ];
    
    $badge = $badges[$status] ?? ['label' => $status, 'class' => 'badge-secondary'];
    return '<span class="badge ' . $badge['class'] . '">' . $badge['label'] . '</span>';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes commandes - Boutique MAT</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/shop.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="container page-content">
        <h1><?= icon('package') ?> Mes commandes</h1>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success_message'] ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if ($order_detail): ?>
            <!-- Détail d'une commande -->
            <div class="order-detail-view">
                <a href="orders.php" class="back-link">← Retour à mes commandes</a>
                
                <div class="order-header">
                    <div>
                        <h2>Commande <?= htmlspecialchars($order_detail['order_number']) ?></h2>
                    <p>Passée le <?= date('d/m/Y à H:i', strtotime($order_detail['created_at'])) ?></p>
                </div>
                <div class="order-status">
                    <?= getStatusBadge($order_detail['order_status']) ?>
                    <?= getPaymentStatusBadge($order_detail['payment_status']) ?>
                </div>
            </div>                <div class="order-info-grid">
                    <div class="info-block">
                        <h3>Adresse de livraison</h3>
                        <p>
                        <?= htmlspecialchars($order_detail['shipping_address']) ?><br>
                        <?= htmlspecialchars($order_detail['shipping_postal_code']) ?> <?= htmlspecialchars($order_detail['shipping_city']) ?><br>
                        <?= htmlspecialchars($order_detail['shipping_country']) ?><br>
                        Tél : <?= htmlspecialchars($order_detail['shipping_phone']) ?>
                        </p>
                    </div>

                    <div class="info-block">
                        <h3>Paiement</h3>
                        <p>
                            Méthode : <?= $order_detail['payment_method'] === 'paypal' ? 'PayPal' : $order_detail['payment_method'] ?><br>
                            Statut : <?= getPaymentStatusBadge($order_detail['payment_status']) ?>
                        </p>
                    </div>

                    <?php if (!empty($order_detail['tracking_number'])): ?>
                        <div class="info-block">
                            <h3>Suivi</h3>
                            <p>
                                Numéro de suivi : <strong><?= htmlspecialchars($order_detail['tracking_number']) ?></strong>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if (!empty($order_detail['customer_notes'])): ?>
                    <div class="info-block">
                        <h3>Notes</h3>
                        <p><?= nl2br(htmlspecialchars($order_detail['customer_notes'])) ?></p>
                    </div>
                <?php endif; ?>

                <h3>Articles commandés</h3>
                <div class="order-items">
                    <?php foreach ($order_items as $item): ?>
                        <div class="order-item">
                            <div class="item-image">
                                <?php if ($item['featured_image']): ?>
                                    <img src="<?= htmlspecialchars($item['featured_image']) ?>" 
                                         alt="<?= htmlspecialchars($item['product_name']) ?>">
                                <?php else: ?>
                                    <div class="image-placeholder">
                                        <?= icon('image') ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="item-details">
                                <h4><?= htmlspecialchars($item['product_name']) ?></h4>
                                <?php if ($item['variant_name']): ?>
                                    <p class="variant"><?= htmlspecialchars($item['variant_name']) ?></p>
                                <?php endif; ?>
                                <p>Quantité : <?= $item['quantity'] ?></p>
                            </div>
                            <div class="item-price">
                                <p><?= number_format($item['price'], 2) ?> €</p>
                                <p class="subtotal">Total : <?= number_format($item['subtotal'], 2) ?> €</p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="order-total">
                    <div class="total-line">
                        <span>Sous-total</span>
                        <span><?= number_format($order_detail['subtotal'], 2) ?> €</span>
                    </div>
                    <div class="total-line">
                        <span>Livraison</span>
                        <span><?= number_format($order_detail['shipping_cost'], 2) ?> €</span>
                    </div>
                    <div class="total-line total">
                        <span><strong>Total</strong></span>
                        <span><strong><?= number_format($order_detail['total'], 2) ?> €</strong></span>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <!-- Liste des commandes -->
            <?php if (empty($orders)): ?>
                <div class="no-orders">
                    <p>Vous n'avez pas encore passé de commande.</p>
                    <a href="shop.php" class="btn btn-primary">Découvrir la boutique</a>
                </div>
            <?php else: ?>
                <div class="orders-list">
                    <?php foreach ($orders as $order): ?>
                        <div class="order-card">
                            <div class="order-card-header">
                                <div>
                                    <h3>Commande <?= htmlspecialchars($order['order_number']) ?></h3>
                                    <p class="order-date">
                                        <?= date('d/m/Y à H:i', strtotime($order['created_at'])) ?>
                                    </p>
                            </div>
                            <div class="order-status">
                                <?= getStatusBadge($order['order_status']) ?>
                            </div>
                        </div>                            <div class="order-card-body">
                        <div class="order-summary-info">
                            <p><strong>Total :</strong> <?= number_format($order['total'], 2) ?> €</p>
                            <p><strong>Paiement :</strong> <?= getPaymentStatusBadge($order['payment_status']) ?></p>
                        </div>                                <?php if (!empty($order['tracking_number'])): ?>
                                    <p class="tracking">
                                        <strong>Suivi :</strong> <?= htmlspecialchars($order['tracking_number']) ?>
                                    </p>
                                <?php endif; ?>
                            </div>

                            <div class="order-card-footer">
                                <a href="orders.php?view=<?= $order['id'] ?>" class="btn btn-secondary">
                                    Voir les détails
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
