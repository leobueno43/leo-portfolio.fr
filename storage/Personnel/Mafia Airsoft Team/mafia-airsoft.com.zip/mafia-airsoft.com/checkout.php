<?php
require_once 'config/database.php';
require_once 'config/session.php';

// Vérifier que l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = "Vous devez être connecté pour passer commande.";
    header('Location: login.php?redirect=' . urlencode('checkout.php'));
    exit;
}

// Récupérer les articles du panier
$stmt = $pdo->prepare("
    SELECT c.*, p.name as product_name, p.price, p.featured_image, p.stock_management, p.stock_quantity,
           v.variant_name, v.stock_quantity as variant_stock
    FROM shop_cart c
    JOIN shop_products p ON c.product_id = p.id
    LEFT JOIN shop_product_variants v ON c.variant_id = v.id
    WHERE c.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$cart_items = $stmt->fetchAll();

if (empty($cart_items)) {
    $_SESSION['error_message'] = "Votre panier est vide.";
    header('Location: cart.php');
    exit;
}

// Calculer le total
$subtotal = 0;
foreach ($cart_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

// Frais de livraison (peut être dynamique)
$shipping_cost = $subtotal >= 50 ? 0 : 5.90;
$total = $subtotal + $shipping_cost;

// Récupérer les informations utilisateur
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    // Récupérer les données du formulaire
    $shipping_address = trim($_POST['shipping_address']);
    $shipping_city = trim($_POST['shipping_city']);
    $shipping_postal_code = trim($_POST['shipping_postal_code']);
    $shipping_country = trim($_POST['shipping_country']);
    $phone = trim($_POST['phone']);
    $notes = trim($_POST['notes'] ?? '');
    
    // Validation
    if (empty($shipping_address) || empty($shipping_city) || empty($shipping_postal_code) || empty($phone)) {
        $error = "Veuillez remplir tous les champs obligatoires.";
    } else {
        // Vérifier à nouveau le stock
        $stock_ok = true;
        foreach ($cart_items as $item) {
            if ($item['stock_management']) {
                $available = $item['variant_id'] ? $item['variant_stock'] : $item['stock_quantity'];
                if ($available < $item['quantity']) {
                    $stock_ok = false;
                    break;
                }
            }
        }
        
        if (!$stock_ok) {
            $error = "Stock insuffisant pour un ou plusieurs articles.";
        } else {
            try {
                $pdo->beginTransaction();
                
                // Créer la commande
                $order_number = 'MAT-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
                
                $stmt = $pdo->prepare("
                    INSERT INTO shop_orders (
                        order_number, user_id, subtotal, shipping_cost, total,
                        shipping_address, shipping_city, shipping_postal_code, shipping_country,
                        shipping_phone, customer_notes, order_status, payment_method, payment_status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'paypal', 'pending')
                ");
                $stmt->execute([
                    $order_number,
                    $_SESSION['user_id'],
                    $subtotal,
                    $shipping_cost,
                    $total,
                    $shipping_address,
                    $shipping_city,
                    $shipping_postal_code,
                    $shipping_country,
                    $phone,
                    $notes
                ]);
                
                $order_id = $pdo->lastInsertId();
                
                // Ajouter les articles de la commande
                foreach ($cart_items as $item) {
                    $stmt = $pdo->prepare("
                        INSERT INTO shop_order_items (
                            order_id, product_id, variant_id, product_name, variant_name, price, quantity, subtotal
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $order_id,
                        $item['product_id'],
                        $item['variant_id'],
                        $item['product_name'],
                        $item['variant_name'],
                        $item['price'],
                        $item['quantity'],
                        $item['price'] * $item['quantity']
                    ]);
                    
                    // Décrémenter le stock
                    if ($item['stock_management']) {
                        if ($item['variant_id']) {
                            $stmt = $pdo->prepare("UPDATE shop_product_variants SET stock_quantity = stock_quantity - ? WHERE id = ?");
                            $stmt->execute([$item['quantity'], $item['variant_id']]);
                        } else {
                            $stmt = $pdo->prepare("UPDATE shop_products SET stock_quantity = stock_quantity - ? WHERE id = ?");
                            $stmt->execute([$item['quantity'], $item['product_id']]);
                        }
                    }
                }
                
                // Vider le panier
                $stmt = $pdo->prepare("DELETE FROM shop_cart WHERE user_id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                
                $pdo->commit();
                
                // Rediriger vers PayPal (simulation pour le moment)
                $_SESSION['success_message'] = "Commande créée avec succès ! Numéro : $order_number";
                $_SESSION['pending_order_id'] = $order_id;
                
                // En production, rediriger vers PayPal
                // header('Location: process_paypal.php?order_id=' . $order_id);
                header('Location: order_success.php?order=' . $order_number);
                exit;
                
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Erreur lors de la création de la commande : " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement - Boutique MAT</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/shop.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="container page-content">
        <h1><?= icon('credit-card') ?> Paiement</h1>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <div class="checkout-container">
            <!-- Formulaire de livraison -->
            <div class="checkout-form">
                <h2>Informations de livraison</h2>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" id="email" value="<?= htmlspecialchars($user['email']) ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label for="shipping_address">Adresse de livraison *</label>
                        <input type="text" name="shipping_address" id="shipping_address" required 
                               value="<?= htmlspecialchars($_POST['shipping_address'] ?? '') ?>">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="shipping_postal_code">Code postal *</label>
                            <input type="text" name="shipping_postal_code" id="shipping_postal_code" required 
                                   value="<?= htmlspecialchars($_POST['shipping_postal_code'] ?? '') ?>">
                        </div>

                        <div class="form-group">
                            <label for="shipping_city">Ville *</label>
                            <input type="text" name="shipping_city" id="shipping_city" required 
                                   value="<?= htmlspecialchars($_POST['shipping_city'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="shipping_country">Pays *</label>
                        <select name="shipping_country" id="shipping_country" required>
                            <option value="France">France</option>
                            <option value="Belgique">Belgique</option>
                            <option value="Suisse">Suisse</option>
                            <option value="Luxembourg">Luxembourg</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="phone">Téléphone *</label>
                        <input type="tel" name="phone" id="phone" required 
                               value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label for="notes">Notes de commande (optionnel)</label>
                        <textarea name="notes" id="notes" rows="3"><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                    </div>

                    <h2 style="margin-top: 30px;">Mode de paiement</h2>
                    
                    <div class="payment-method">
                        <input type="radio" id="paypal" name="payment_method" value="paypal" checked>
                        <label for="paypal">
                            <strong>PayPal</strong> - Paiement sécurisé via PayPal
                        </label>
                    </div>

                    <button type="submit" name="place_order" class="btn btn-primary btn-large">
                        Commander et payer (<?= number_format($total, 2) ?> €)
                    </button>

                    <p class="checkout-note">
                        En passant commande, vous acceptez nos conditions générales de vente.
                    </p>
                </form>
            </div>

            <!-- Récapitulatif de commande -->
            <div class="order-summary">
                <h2>Récapitulatif</h2>
                
                <div class="summary-items">
                    <?php foreach ($cart_items as $item): ?>
                        <div class="summary-item">
                            <div class="item-info">
                                <p class="item-name">
                                    <?= htmlspecialchars($item['product_name']) ?>
                                    <?php if ($item['variant_name']): ?>
                                        <br><small><?= htmlspecialchars($item['variant_name']) ?></small>
                                    <?php endif; ?>
                                </p>
                                <p class="item-quantity">x<?= $item['quantity'] ?></p>
                            </div>
                            <p class="item-price"><?= number_format($item['price'] * $item['quantity'], 2) ?> €</p>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="summary-totals">
                    <div class="summary-line">
                        <span>Sous-total</span>
                        <span><?= number_format($subtotal, 2) ?> €</span>
                    </div>
                    
                    <div class="summary-line">
                        <span>Livraison</span>
                        <span>
                            <?php if ($shipping_cost > 0): ?>
                                <?= number_format($shipping_cost, 2) ?> €
                            <?php else: ?>
                                Gratuite
                            <?php endif; ?>
                        </span>
                    </div>
                    
                    <?php if ($subtotal < 50 && $shipping_cost > 0): ?>
                        <p class="shipping-note">
                            Livraison gratuite à partir de 50€ d'achat
                        </p>
                    <?php endif; ?>
                    
                    <div class="summary-total">
                        <span>Total</span>
                        <span><?= number_format($total, 2) ?> €</span>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
