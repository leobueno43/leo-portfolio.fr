# 📝 Guide : Activer/Désactiver la billetterie par événement

## ✅ Fonctionnalité implémentée !

Vous pouvez maintenant **activer ou désactiver** la génération automatique de billets pour chaque événement individuellement.

---

## 🗄️ Mise à jour de la base de données

**⚠️ IMPORTANT** : Exécutez d'abord ce script SQL dans phpMyAdmin :

```sql
-- Exécuter ce fichier dans phpMyAdmin
source database/add_enable_ticketing.sql;

-- OU directement :
ALTER TABLE events 
ADD COLUMN enable_ticketing TINYINT(1) DEFAULT 1 
COMMENT 'Activer la billetterie pour cet événement (1 = oui, 0 = non)';
```

---

## 🎯 Utilisation

### Lors de la création d'un événement

1. Allez sur `admin/create_event.php`
2. Remplissez les informations de la partie
3. Dans la section **"Options"**, vous verrez :
   - ☑️ **Inscriptions ouvertes**
   - ☑️ **🎫 Activer la billetterie (génération et envoi automatique de billets)**

4. **Si coché** : Les joueurs recevront automatiquement un billet PDF par email à l'inscription
5. **Si décoché** : Les joueurs seront simplement inscrits, sans billet

6. Cliquez sur **"Créer la partie"**

### Lors de la modification d'un événement

1. Allez sur `admin/edit_event.php?id=X`
2. Dans la section **"Options"**, activez ou désactivez la checkbox :
   - ☑️ **🎫 Activer la billetterie**
3. Cliquez sur **"💾 Enregistrer les modifications"**

---

## 💡 Cas d'usage

### ✅ Activer la billetterie (coché)

**Pour quoi ?**
- Événements officiels avec contrôle d'entrée
- Parties payantes nécessitant un justificatif
- Grandes parties avec scanner QR à l'entrée
- Parties avec gestion stricte des présences

**Comportement :**
- Génération automatique du billet PDF
- QR code unique créé
- Email envoyé instantanément au joueur
- Billet supprimé si désinscription

**Exemple :** "Opération Aiguille Noire - 50 joueurs - Entrée contrôlée"

### ❌ Désactiver la billetterie (décoché)

**Pour quoi ?**
- Entraînements informels
- Petites parties entre amis
- Événements sans contrôle d'entrée
- Événements gratuits et flexibles
- Parties "last minute"

**Comportement :**
- Inscription simple dans la base de données
- Pas de génération de PDF/QR code
- Pas d'email de billet
- Liste des inscrits visible normalement

**Exemple :** "Entraînement du samedi - Informel - Pas de billetterie"

---

## 🔧 Fonctionnement technique

### Code ajouté

**1. Base de données :**
```sql
ALTER TABLE events ADD COLUMN enable_ticketing TINYINT(1) DEFAULT 1;
```

**2. Formulaires admin :**
- `create_event.php` : Checkbox ajoutée
- `edit_event.php` : Checkbox ajoutée

**3. Logique d'inscription (`event.php`) :**
```php
// Vérification automatique lors de l'inscription
$ticketResult = processTicketAfterRegistration($pdo, $event_id, $user_id);

if ($ticketResult['skipped']) {
    // Billetterie désactivée
    $message = 'Inscription réussie !';
} else {
    // Billetterie activée
    $message = 'Inscription réussie ! 🎫 Billet envoyé par email';
}
```

**4. Fonction de génération (`ticket_integration.php`) :**
```php
function processTicketAfterRegistration($pdo, $eventId, $userId) {
    // Vérifier si billetterie activée
    $stmt = $pdo->prepare("SELECT enable_ticketing FROM events WHERE id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event['enable_ticketing']) {
        return ['success' => true, 'skipped' => true];
    }
    
    // Générer le billet normalement...
}
```

---

## 🎭 Comportement par défaut

- **Nouveaux événements** : Billetterie **ACTIVÉE** par défaut (checkbox cochée)
- **Événements existants** : Après migration SQL, tous auront la billetterie **ACTIVÉE**
- **Si le champ n'existe pas** : Le système considère que c'est activé (rétrocompatibilité)

---

## 📊 Interface utilisateur

### Message selon le mode

**Billetterie activée :**
```
✅ Inscription réussie ! Vous avez rejoint Équipe Bleue.
🎫 Votre billet a été envoyé par email !
```

**Billetterie désactivée :**
```
✅ Inscription réussie ! Vous avez rejoint Équipe Bleue.
```

### Pas de changement pour :
- La liste des équipes
- Le processus d'inscription
- L'affichage des inscrits
- Les autres fonctionnalités

---

## 🧪 Tests

### Tester avec billetterie activée

1. Créer un événement avec checkbox cochée
2. S'inscrire en tant que joueur
3. Vérifier :
   - ✅ Billet PDF dans `uploads/tickets/`
   - ✅ QR code dans `uploads/qrcodes/`
   - ✅ Email reçu avec pièce jointe
   - ✅ Entrée dans la table `event_tickets`

### Tester avec billetterie désactivée

1. Créer un événement avec checkbox **décochée**
2. S'inscrire en tant que joueur
3. Vérifier :
   - ✅ Inscription dans `registrations`
   - ❌ Pas de billet PDF créé
   - ❌ Pas de QR code
   - ❌ Pas d'email de billet
   - ❌ Pas d'entrée dans `event_tickets`
   - ✅ Message "Inscription réussie !" (sans mention de billet)

---

## 🔍 Vérification en base de données

```sql
-- Voir le statut de billetterie de tous les événements
SELECT id, title, event_date, enable_ticketing 
FROM events 
ORDER BY event_date DESC;

-- Activer la billetterie pour un événement spécifique
UPDATE events SET enable_ticketing = 1 WHERE id = 5;

-- Désactiver la billetterie pour un événement spécifique
UPDATE events SET enable_ticketing = 0 WHERE id = 5;

-- Compter les billets générés par événement
SELECT e.title, COUNT(t.id) as nombre_billets
FROM events e
LEFT JOIN event_tickets t ON e.id = t.event_id
GROUP BY e.id;
```

---

## ❓ FAQ

### Q: Si je désactive la billetterie après que des joueurs se soient inscrits ?
**R:** Les billets déjà générés restent valides. Les nouvelles inscriptions ne généreront plus de billets.

### Q: Peut-on réactiver la billetterie plus tard ?
**R:** Oui ! Modifiez l'événement et recochez la case. Les nouvelles inscriptions généreront des billets.

### Q: Les joueurs déjà inscrits recevront-ils un billet si je réactive ?
**R:** Non. Seules les **nouvelles inscriptions** après réactivation généreront des billets.

### Q: Puis-je générer des billets manuellement pour un événement sans billetterie ?
**R:** Oui, en tant qu'admin, vous pouvez utiliser les outils du dashboard billetterie pour générer des billets manuellement si besoin.

### Q: Le scanner QR fonctionne-t-il toujours ?
**R:** Oui ! Le scanner (`qr-code/scan.php`) fonctionne normalement et validera uniquement les billets existants.

---

## ✅ Avantages

1. **Flexibilité** : Choisissez au cas par cas
2. **Économie** : Pas de génération inutile pour les petites parties
3. **Performance** : Moins de charge serveur pour les événements informels
4. **Simplicité** : Inscription rapide sans billetterie pour événements légers
5. **Professionnalisme** : Billetterie complète pour les grandes parties officielles

---

## 🚀 Prochaines étapes possibles

- [ ] Statistiques : Nombre d'événements avec/sans billetterie
- [ ] Notification admin : Alert si billetterie désactivée
- [ ] Badge visuel : Afficher "Avec billetterie" sur la liste des événements
- [ ] Génération rétroactive : Bouton pour générer des billets pour inscrits existants

---

**✅ Fonctionnalité implémentée et prête à l'emploi !**
