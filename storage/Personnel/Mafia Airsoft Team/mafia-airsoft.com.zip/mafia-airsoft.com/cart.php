<?php
require_once 'config/database.php';
require_once 'config/session.php';

// Gérer les actions du panier
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_quantity'])) {
        $item_id = $_POST['item_id'];
        $quantity = max(1, (int)$_POST['quantity']);
        
        if (isset($_SESSION['user_id'])) {
            $stmt = $pdo->prepare("UPDATE shop_cart SET quantity = ? WHERE id = ? AND user_id = ?");
            $stmt->execute([$quantity, $item_id, $_SESSION['user_id']]);
        } else {
            if (isset($_SESSION['cart'][$item_id])) {
                $_SESSION['cart'][$item_id]['quantity'] = $quantity;
            }
        }
        
        $_SESSION['success_message'] = "Quantité mise à jour.";
    }
    
    if (isset($_POST['remove_item'])) {
        $item_id = $_POST['item_id'];
        
        if (isset($_SESSION['user_id'])) {
            $stmt = $pdo->prepare("DELETE FROM shop_cart WHERE id = ? AND user_id = ?");
            $stmt->execute([$item_id, $_SESSION['user_id']]);
        } else {
            unset($_SESSION['cart'][$item_id]);
        }
        
        $_SESSION['success_message'] = "Article retiré du panier.";
    }
    
    if (isset($_POST['clear_cart'])) {
        if (isset($_SESSION['user_id'])) {
            $stmt = $pdo->prepare("DELETE FROM shop_cart WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
        } else {
            $_SESSION['cart'] = [];
        }
        
        $_SESSION['success_message'] = "Panier vidé.";
    }
    
    header('Location: cart.php');
    exit;
}

// Récupérer les articles du panier
$cart_items = [];
$total = 0;

if (isset($_SESSION['user_id'])) {
    // Utilisateur connecté : récupérer depuis la base
    $stmt = $pdo->prepare("
        SELECT c.*, p.name as product_name, p.price, p.featured_image, p.stock_management, p.stock_quantity,
               v.variant_name, v.stock_quantity as variant_stock
        FROM shop_cart c
        JOIN shop_products p ON c.product_id = p.id
        LEFT JOIN shop_product_variants v ON c.variant_id = v.id
        WHERE c.user_id = ?
        ORDER BY c.added_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $cart_items = $stmt->fetchAll();
} else {
    // Utilisateur non connecté : récupérer depuis la session
    if (!empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $key => $item) {
            $stmt = $pdo->prepare("
                SELECT p.*, v.variant_name, v.stock_quantity as variant_stock
                FROM shop_products p
                LEFT JOIN shop_product_variants v ON v.id = ?
                WHERE p.id = ?
            ");
            $stmt->execute([$item['variant_id'], $item['product_id']]);
            $product = $stmt->fetch();
            
            if ($product) {
                $cart_items[] = [
                    'id' => $key,
                    'product_id' => $item['product_id'],
                    'variant_id' => $item['variant_id'],
                    'quantity' => $item['quantity'],
                    'price' => $product['price'],
                    'product_name' => $product['name'],
                    'featured_image' => $product['featured_image'],
                    'stock_management' => $product['stock_management'],
                    'stock_quantity' => $product['stock_quantity'],
                    'variant_name' => $product['variant_name'],
                    'variant_stock' => $product['variant_stock']
                ];
            }
        }
    }
}

// Calculer le total
foreach ($cart_items as $item) {
    $total += $item['price'] * $item['quantity'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panier - Boutique MAT</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/shop.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="container page-content">
        <h1><?= icon('shopping-cart') ?> Mon Panier</h1>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success_message'] ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if (empty($cart_items)): ?>
            <div class="empty-cart">
                <p>Votre panier est vide.</p>
                <a href="shop.php" class="btn btn-primary">Continuer mes achats</a>
            </div>
        <?php else: ?>
            <div class="cart-container">
                <div class="cart-items">
                    <?php foreach ($cart_items as $item): ?>
                        <?php 
                        // Vérifier la disponibilité du stock
                        $stock_available = true;
                        $max_quantity = 99;
                        
                        if ($item['stock_management']) {
                            if ($item['variant_id']) {
                                $max_quantity = $item['variant_stock'];
                                $stock_available = $item['variant_stock'] >= $item['quantity'];
                            } else {
                                $max_quantity = $item['stock_quantity'];
                                $stock_available = $item['stock_quantity'] >= $item['quantity'];
                            }
                        }
                        ?>
                        <div class="cart-item <?= !$stock_available ? 'out-of-stock' : '' ?>">
                            <div class="cart-item-image">
                                <?php if ($item['featured_image']): ?>
                                    <img src="<?= htmlspecialchars($item['featured_image']) ?>" 
                                         alt="<?= htmlspecialchars($item['product_name']) ?>">
                                <?php else: ?>
                                    <div class="image-placeholder">
                                        <?= icon('image') ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="cart-item-details">
                                <h3>
                                    <a href="product.php?id=<?= $item['product_id'] ?>">
                                        <?= htmlspecialchars($item['product_name']) ?>
                                    </a>
                                </h3>
                                <?php if ($item['variant_name']): ?>
                                    <p class="variant-info"><?= htmlspecialchars($item['variant_name']) ?></p>
                                <?php endif; ?>
                                
                                <?php if (!$stock_available): ?>
                                    <p class="stock-warning">⚠ Stock insuffisant</p>
                                <?php endif; ?>
                            </div>

                            <div class="cart-item-quantity">
                                <form method="POST" class="quantity-form" id="form-<?= $item['id'] ?>">
                                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                                    <input type="hidden" name="update_quantity" value="1">
                                    <input type="number" name="quantity" value="<?= $item['quantity'] ?>" 
                                           min="1" max="<?= $max_quantity ?>" 
                                           class="quantity-input"
                                           data-item-id="<?= $item['id'] ?>"
                                           onchange="updateQuantity(this)">
                                </form>
                            </div>

                            <div class="cart-item-price">
                                <p class="price"><?= number_format($item['price'], 2) ?> €</p>
                                <p class="subtotal">Sous-total : <?= number_format($item['price'] * $item['quantity'], 2) ?> €</p>
                            </div>

                            <div class="cart-item-actions">
                                <form method="POST">
                                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                                    <button type="submit" name="remove_item" class="btn btn-danger btn-sm" 
                                            onclick="return confirm('Retirer cet article du panier ?')">
                                        <?= icon('trash') ?> Retirer
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="cart-summary">
                    <h2>Résumé de la commande</h2>
                    
                    <div class="summary-line">
                        <span>Sous-total (<?= count($cart_items) ?> article<?= count($cart_items) > 1 ? 's' : '' ?>)</span>
                        <span><?= number_format($total, 2) ?> €</span>
                    </div>
                    
                    <div class="summary-line">
                        <span>Livraison</span>
                        <span>Calculée à l'étape suivante</span>
                    </div>
                    
                    <div class="summary-total">
                        <span>Total</span>
                        <span><?= number_format($total, 2) ?> €</span>
                    </div>

                    <?php 
                    // Vérifier si tous les articles sont disponibles
                    $all_available = true;
                    foreach ($cart_items as $item) {
                        if ($item['stock_management']) {
                            $stock = $item['variant_id'] ? $item['variant_stock'] : $item['stock_quantity'];
                            if ($stock < $item['quantity']) {
                                $all_available = false;
                                break;
                            }
                        }
                    }
                    ?>

                    <?php if ($all_available): ?>
                        <a href="checkout.php" class="btn btn-primary btn-large">
                            Procéder au paiement
                        </a>
                    <?php else: ?>
                        <button class="btn btn-primary btn-large" disabled>
                            Stock insuffisant
                        </button>
                        <p class="warning-text">Veuillez ajuster les quantités avant de continuer.</p>
                    <?php endif; ?>

                    <a href="shop.php" class="btn btn-secondary">Continuer mes achats</a>

                    <form method="POST" style="margin-top: 20px;">
                        <button type="submit" name="clear_cart" class="btn btn-link" 
                                onclick="return confirm('Vider tout le panier ?')">
                            Vider le panier
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <?php include 'includes/footer.php'; ?>
    
    <script>
        function updateQuantity(input) {
            const itemId = input.getAttribute('data-item-id');
            const form = document.getElementById('form-' + itemId);
            
            // Soumettre le formulaire automatiquement
            form.submit();
        }
    </script>
</body>
</html>
