<?php
/**
 * Configuration pour l'envoi d'emails
 * Modifiez ces paramètres selon votre serveur SMTP
 */

// Configuration SMTP
define('SMTP_HOST', 'smtp.gmail.com'); // Ou votre serveur SMTP
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'leo.bueno0763@gmail.com'); // Votre email
define('SMTP_PASSWORD', 'xfpu vnex dval mrzx'); // Mot de passe ou App Password
define('SMTP_SECURE', 'tls'); // 'tls' ou 'ssl'

// Email d'expédition
define('FROM_EMAIL', 'noreply@mat.com');
define('FROM_NAME', 'MAT - Billetterie');

// Email de réponse
define('REPLY_TO_EMAIL', 'contact@mat.com');
define('REPLY_TO_NAME', 'MAT Support');

// Configuration des billets
define('TICKET_VALIDITY_HOURS', 24); // Validité du billet en heures avant l'événement
define('QR_CODE_SIZE', 300); // Taille du QR code en pixels

?>