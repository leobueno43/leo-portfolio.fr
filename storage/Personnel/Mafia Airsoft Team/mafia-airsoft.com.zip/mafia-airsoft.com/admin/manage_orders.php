<?php
require_once '../config/database.php';
require_once '../config/session.php';

// Vérifier les permissions admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Filtres
$status_filter = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';

// Mettre à jour le statut d'une commande
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    $tracking_number = $_POST['tracking_number'] ?? null;
    
    $stmt = $pdo->prepare("
        UPDATE shop_orders 
        SET order_status = ?, tracking_number = ?, updated_at = NOW() 
        WHERE id = ?
    ");
    $stmt->execute([$new_status, $tracking_number, $order_id]);
    
    $_SESSION['success_message'] = "Commande mise à jour avec succès.";
    header('Location: manage_orders.php');
    exit;
}

// Supprimer une commande
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_order'])) {
    $order_id = $_POST['order_id'];
    
    try {
        $pdo->beginTransaction();
        
        // Supprimer les articles de la commande (cascade automatique avec FK)
        // Supprimer la commande
        $stmt = $pdo->prepare("DELETE FROM shop_orders WHERE id = ?");
        $stmt->execute([$order_id]);
        
        $pdo->commit();
        $_SESSION['success_message'] = "Commande supprimée avec succès.";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Erreur lors de la suppression : " . $e->getMessage();
    }
    
    header('Location: manage_orders.php');
    exit;
}

// Construire la requête
$where = [];
$params = [];

if ($status_filter) {
    $where[] = "o.order_status = ?";
    $params[] = $status_filter;
}

if ($search) {
    $where[] = "(o.order_number LIKE ? OR u.email LIKE ? OR u.pseudo LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$where_clause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

// Récupérer les commandes
$stmt = $pdo->prepare("
    SELECT o.*, u.email, u.pseudo,
           COUNT(oi.id) as items_count
    FROM shop_orders o
    JOIN users u ON o.user_id = u.id
    LEFT JOIN shop_order_items oi ON o.id = oi.order_id
    $where_clause
    GROUP BY o.id
    ORDER BY o.created_at DESC
");
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Statistiques
$stats = $pdo->query("
    SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN order_status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN order_status = 'processing' THEN 1 ELSE 0 END) as processing,
        SUM(CASE WHEN order_status = 'shipped' THEN 1 ELSE 0 END) as shipped,
        SUM(CASE WHEN order_status = 'delivered' THEN 1 ELSE 0 END) as delivered,
        SUM(total) as total_revenue
    FROM shop_orders
")->fetch();

function getStatusBadge($status) {
    $badges = [
        'pending' => ['label' => 'En attente', 'class' => 'badge-warning'],
        'processing' => ['label' => 'En traitement', 'class' => 'badge-info'],
        'shipped' => ['label' => 'Expédiée', 'class' => 'badge-primary'],
        'delivered' => ['label' => 'Livrée', 'class' => 'badge-success'],
        'cancelled' => ['label' => 'Annulée', 'class' => 'badge-danger']
    ];
    
    $badge = $badges[$status] ?? ['label' => $status, 'class' => 'badge-secondary'];
    return '<span class="badge ' . $badge['class'] . '">' . $badge['label'] . '</span>';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des commandes - Admin MAT</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/shop.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container admin-content">
        <h1>Gestion des commandes</h1>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success_message'] ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <!-- Statistiques -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total commandes</h3>
                <p class="stat-number"><?= $stats['total_orders'] ?></p>
            </div>
            <div class="stat-card warning">
                <h3>En attente</h3>
                <p class="stat-number"><?= $stats['pending'] ?></p>
            </div>
            <div class="stat-card info">
                <h3>En traitement</h3>
                <p class="stat-number"><?= $stats['processing'] ?></p>
            </div>
            <div class="stat-card primary">
                <h3>Expédiées</h3>
                <p class="stat-number"><?= $stats['shipped'] ?></p>
            </div>
            <div class="stat-card success">
                <h3>Revenus</h3>
                <p class="stat-number"><?= number_format($stats['total_revenue'], 2) ?> €</p>
            </div>
        </div>

        <!-- Filtres -->
        <div class="filters-section">
            <form method="GET" class="filters-form">
                <select name="status" onchange="this.form.submit()">
                    <option value="">Tous les statuts</option>
                    <option value="pending" <?= $status_filter === 'pending' ? 'selected' : '' ?>>En attente</option>
                    <option value="processing" <?= $status_filter === 'processing' ? 'selected' : '' ?>>En traitement</option>
                    <option value="shipped" <?= $status_filter === 'shipped' ? 'selected' : '' ?>>Expédiée</option>
                    <option value="delivered" <?= $status_filter === 'delivered' ? 'selected' : '' ?>>Livrée</option>
                    <option value="cancelled" <?= $status_filter === 'cancelled' ? 'selected' : '' ?>>Annulée</option>
                </select>

                <input type="search" name="search" placeholder="Rechercher..." value="<?= htmlspecialchars($search) ?>">
                
                <button type="submit" class="btn btn-primary">Filtrer</button>
                <?php if ($status_filter || $search): ?>
                    <a href="manage_orders.php" class="btn btn-secondary">Réinitialiser</a>
                <?php endif; ?>
            </form>
        </div>

        <!-- Liste des commandes -->
        <div class="orders-table">
            <table>
                <thead>
                    <tr>
                        <th>Numéro</th>
                        <th>Client</th>
                        <th>Date</th>
                        <th>Articles</th>
                        <th>Total</th>
                        <th>Statut</th>
                        <th>Paiement</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= htmlspecialchars($order['order_number']) ?></td>
                            <td>
                                <?= htmlspecialchars($order['pseudo']) ?><br>
                                <small><?= htmlspecialchars($order['email']) ?></small>
                            </td>
                            <td><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td>
                            <td><?= $order['items_count'] ?></td>
                            <td><?= number_format($order['total'], 2) ?> €</td>
                            <td><?= getStatusBadge($order['order_status']) ?></td>
                            <td>
                                <span class="badge <?= $order['payment_status'] === 'paid' ? 'badge-success' : 'badge-warning' ?>">
                                    <?= $order['payment_status'] === 'paid' ? 'Payé' : 'En attente' ?>
                                </span>
                            </td>
                            <td>
                                <button onclick="showOrderModal(<?= $order['id'] ?>, '<?= htmlspecialchars($order['order_status'], ENT_QUOTES) ?>', '<?= htmlspecialchars($order['tracking_number'] ?? '', ENT_QUOTES) ?>')" 
                                        class="btn btn-sm btn-primary">
                                    Modifier
                                </button>
                                <a href="../orders.php?view=<?= $order['id'] ?>" class="btn btn-sm btn-secondary" target="_blank">
                                    Voir
                                </a>
                                <button onclick="deleteOrder(<?= $order['id'] ?>, '<?= htmlspecialchars($order['order_number'], ENT_QUOTES) ?>')" 
                                        class="btn btn-sm btn-danger">
                                    Supprimer
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Modal de modification -->
    <div id="orderModal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close" onclick="closeOrderModal()">&times;</span>
            <h2>Modifier la commande</h2>
            
            <form method="POST">
                <input type="hidden" name="order_id" id="modal_order_id">
                
                <div class="form-group">
                    <label for="status">Statut de la commande</label>
                    <select name="status" id="modal_status" required>
                        <option value="pending">En attente</option>
                        <option value="processing">En traitement</option>
                        <option value="shipped">Expédiée</option>
                        <option value="delivered">Livrée</option>
                        <option value="cancelled">Annulée</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="tracking_number">Numéro de suivi (optionnel)</label>
                    <input type="text" name="tracking_number" id="modal_tracking">
                </div>

                <button type="submit" name="update_status" class="btn btn-primary">Enregistrer</button>
                <button type="button" onclick="closeOrderModal()" class="btn btn-secondary">Annuler</button>
            </form>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script>
        function showOrderModal(orderId, status, tracking) {
            document.getElementById('modal_order_id').value = orderId;
            document.getElementById('modal_status').value = status;
            document.getElementById('modal_tracking').value = tracking;
            document.getElementById('orderModal').style.display = 'block';
        }

        function closeOrderModal() {
            document.getElementById('orderModal').style.display = 'none';
        }

        // Fermer le modal en cliquant en dehors
        window.onclick = function(event) {
            const modal = document.getElementById('orderModal');
            if (event.target === modal) {
                closeOrderModal();
            }
        }

        function deleteOrder(orderId, orderNumber) {
            if (confirm('Êtes-vous sûr de vouloir supprimer la commande ' + orderNumber + ' ?\n\nCette action est irréversible et supprimera tous les articles associés.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'manage_orders.php';
                
                const orderInput = document.createElement('input');
                orderInput.type = 'hidden';
                orderInput.name = 'order_id';
                orderInput.value = orderId;
                
                const deleteInput = document.createElement('input');
                deleteInput.type = 'hidden';
                deleteInput.name = 'delete_order';
                deleteInput.value = '1';
                
                form.appendChild(orderInput);
                form.appendChild(deleteInput);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>
