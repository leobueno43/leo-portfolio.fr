<?php
require_once '../config/database.php';
require_once '../config/session.php';
requireAdmin();

$message = '';
$error = '';
$edit_product = null;

// Récupérer un produit à éditer
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM shop_products WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_product = $stmt->fetch();
    
    if ($edit_product) {
        // Récupérer les variantes
        $stmt_variants = $pdo->prepare("SELECT * FROM shop_product_variants WHERE product_id = ? ORDER BY id ASC");
        $stmt_variants->execute([$edit_product['id']]);
        $product_variants = $stmt_variants->fetchAll();
        
        // Récupérer les images
        $stmt_images = $pdo->prepare("SELECT * FROM shop_product_images WHERE product_id = ? ORDER BY display_order ASC");
        $stmt_images->execute([$edit_product['id']]);
        $product_images = $stmt_images->fetchAll();
    }
}

// Gérer la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'update') {
        $category_id = $_POST['category_id'] ?? null;
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $stock_quantity = intval($_POST['stock_quantity'] ?? 0);
        $stock_management = isset($_POST['stock_management']) ? 1 : 0;
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        // Gérer l'upload de l'image principale
        $featured_image = $edit_product['featured_image'] ?? '';
        if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../uploads/shop/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_extension = strtolower(pathinfo($_FILES['featured_image']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            if (in_array($file_extension, $allowed)) {
                $new_filename = 'product_' . time() . '_' . uniqid() . '.' . $file_extension;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['featured_image']['tmp_name'], $upload_path)) {
                    if ($action === 'update' && !empty($edit_product['featured_image']) && file_exists('../' . $edit_product['featured_image'])) {
                        unlink('../' . $edit_product['featured_image']);
                    }
                    $featured_image = 'uploads/shop/' . $new_filename;
                }
            }
        }
        
        // Générer le slug
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
        
        if (empty($name) || $price < 0) {
            $error = 'Le nom et le prix sont obligatoires.';
        } else {
            if ($action === 'create') {
                $stmt = $pdo->prepare("
                    INSERT INTO shop_products (category_id, name, slug, description, featured_image, price, stock_quantity, stock_management, is_featured, is_active)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                if ($stmt->execute([$category_id, $name, $slug, $description, $featured_image, $price, $stock_quantity, $stock_management, $is_featured, $is_active])) {
                    $product_id = $pdo->lastInsertId();
                    
                    // Gérer les variantes
                    if (!empty($_POST['variant_names'])) {
                        $stmt_variant = $pdo->prepare("INSERT INTO shop_product_variants (product_id, variant_name, sku, stock_quantity) VALUES (?, ?, ?, ?)");
                        foreach ($_POST['variant_names'] as $index => $variant_name) {
                            if (!empty($variant_name)) {
                                $sku = $_POST['variant_skus'][$index] ?? '';
                                $variant_stock = intval($_POST['variant_stocks'][$index] ?? 0);
                                $stmt_variant->execute([$product_id, $variant_name, $sku, $variant_stock]);
                            }
                        }
                    }
                    
                    $message = 'Produit créé avec succès !';
                } else {
                    $error = 'Erreur lors de la création.';
                }
            } else {
                $product_id = $_POST['product_id'];
                $stmt = $pdo->prepare("
                    UPDATE shop_products 
                    SET category_id = ?, name = ?, slug = ?, description = ?, featured_image = ?, price = ?, stock_quantity = ?, stock_management = ?, is_featured = ?, is_active = ?
                    WHERE id = ?
                ");
                if ($stmt->execute([$category_id, $name, $slug, $description, $featured_image, $price, $stock_quantity, $stock_management, $is_featured, $is_active, $product_id])) {
                    $message = 'Produit mis à jour !';
                    $edit_product = null;
                } else {
                    $error = 'Erreur lors de la mise à jour.';
                }
            }
        }
    } elseif ($action === 'delete') {
        $product_id = $_POST['product_id'];
        $stmt = $pdo->prepare("DELETE FROM shop_products WHERE id = ?");
        if ($stmt->execute([$product_id])) {
            $message = 'Produit supprimé !';
        }
    } elseif ($action === 'delete_variant') {
        $variant_id = $_POST['variant_id'];
        $stmt = $pdo->prepare("DELETE FROM shop_product_variants WHERE id = ?");
        if ($stmt->execute([$variant_id])) {
            $message = 'Variante supprimée !';
        }
    }
}

// Récupérer toutes les catégories
$categories = $pdo->query("SELECT * FROM shop_categories ORDER BY display_order ASC")->fetchAll();

// Récupérer tous les produits
$stmt = $pdo->query("
    SELECT p.*, c.name as category_name
    FROM shop_products p
    LEFT JOIN shop_categories c ON p.category_id = c.id
    ORDER BY p.created_at DESC
");
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion de la Boutique - Administration</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container page-content">
        <h1><?= icon('shopping-bag') ?> Gestion de la Boutique</h1>

        <?php if ($message): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Formulaire de création/édition -->
        <section class="admin-section">
            <h2><?= $edit_product ? icon('edit') . ' Modifier le produit' : icon('plus') . ' Nouveau produit' ?></h2>
            <form method="POST" class="admin-form" enctype="multipart/form-data">
                <input type="hidden" name="action" value="<?= $edit_product ? 'update' : 'create' ?>">
                <?php if ($edit_product): ?>
                    <input type="hidden" name="product_id" value="<?= $edit_product['id'] ?>">
                <?php endif; ?>

                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Nom du produit *</label>
                        <input type="text" id="name" name="name" required 
                               value="<?= htmlspecialchars($edit_product['name'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label for="category_id">Catégorie</label>
                        <select id="category_id" name="category_id">
                            <option value="">Sans catégorie</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= ($edit_product['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="4"><?= htmlspecialchars($edit_product['description'] ?? '') ?></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="price">Prix (€) *</label>
                        <input type="number" id="price" name="price" step="0.01" min="0" required 
                               value="<?= htmlspecialchars($edit_product['price'] ?? '0.00') ?>">
                    </div>

                    <div class="form-group">
                        <label for="stock_quantity">Stock</label>
                        <input type="number" id="stock_quantity" name="stock_quantity" min="0" 
                               value="<?= htmlspecialchars($edit_product['stock_quantity'] ?? '0') ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="featured_image">Image du produit</label>
                    <input type="file" id="featured_image" name="featured_image" accept="image/*" onchange="previewImage(event)">
                    
                    <?php if (!empty($edit_product['featured_image'])): ?>
                        <div id="current-image" style="margin-top: 15px;">
                            <p><strong>Image actuelle :</strong></p>
                            <img src="../<?= htmlspecialchars($edit_product['featured_image']) ?>" 
                                 alt="Image actuelle" 
                                 style="max-width: 200px; border-radius: 5px;">
                        </div>
                    <?php endif; ?>
                    
                    <div id="image-preview" style="margin-top: 15px; display: none;">
                        <p><strong>Aperçu :</strong></p>
                        <img id="preview-img" src="" alt="Aperçu" style="max-width: 200px; border-radius: 5px;">
                    </div>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="stock_management" <?= ($edit_product['stock_management'] ?? 1) ? 'checked' : '' ?>>
                        Gérer le stock (décocher pour stock illimité)
                    </label>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_featured" <?= ($edit_product['is_featured'] ?? 0) ? 'checked' : '' ?>>
                        Produit mis en avant
                    </label>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_active" <?= ($edit_product['is_active'] ?? 1) ? 'checked' : '' ?>>
                        Produit actif (visible)
                    </label>
                </div>

                <!-- Variantes -->
                <?php if (!$edit_product): ?>
                <div class="form-group">
                    <label><strong>Variantes (tailles, couleurs...)</strong></label>
                    <div id="variants-container">
                        <div class="variant-row" style="display: flex; gap: 10px; margin-bottom: 10px;">
                            <input type="text" name="variant_names[]" placeholder="Ex: Taille S" style="flex: 2;">
                            <input type="text" name="variant_skus[]" placeholder="SKU (optionnel)" style="flex: 2;">
                            <input type="number" name="variant_stocks[]" placeholder="Stock" min="0" value="0" style="flex: 1;">
                        </div>
                    </div>
                    <button type="button" onclick="addVariant()" class="btn btn-secondary btn-sm">+ Ajouter une variante</button>
                </div>
                <?php endif; ?>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <?= $edit_product ? 'Mettre à jour' : 'Créer le produit' ?>
                    </button>
                    <?php if ($edit_product): ?>
                        <a href="manage_shop.php" class="btn btn-secondary">Annuler</a>
                    <?php endif; ?>
                </div>
            </form>
        </section>

        <!-- Liste des produits -->
        <section class="admin-section">
            <h2>📦 Tous les produits</h2>
            <?php if (empty($products)): ?>
                <p class="no-data">Aucun produit créé.</p>
            <?php else: ?>
                <div class="admin-table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Nom</th>
                                <th>Catégorie</th>
                                <th>Prix</th>
                                <th>Stock</th>
                                <th>Ventes</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td>
                                        <?php if ($product['featured_image']): ?>
                                            <img src="../<?= htmlspecialchars($product['featured_image']) ?>" 
                                                 alt="<?= htmlspecialchars($product['name']) ?>" 
                                                 style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                                        <?php else: ?>
                                            <div style="width: 50px; height: 50px; background: #ddd; border-radius: 5px;"></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><strong><?= htmlspecialchars($product['name']) ?></strong></td>
                                    <td><?= htmlspecialchars($product['category_name'] ?? 'Sans catégorie') ?></td>
                                    <td><?= number_format($product['price'], 2) ?> €</td>
                                    <td><?= $product['stock_management'] ? $product['stock_quantity'] : '∞' ?></td>
                                    <td><?= $product['sales_count'] ?></td>
                                    <td>
                                        <?php if ($product['is_active']): ?>
                                            <span class="badge badge-success">Actif</span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">Inactif</span>
                                        <?php endif; ?>
                                        <?php if ($product['is_featured']): ?>
                                            <span class="badge badge-info">⭐</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="table-actions">
                                        <a href="?edit=<?= $product['id'] ?>" class="btn-action" title="Modifier"><?= icon('edit') ?></a>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Supprimer ce produit ?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                            <button type="submit" class="btn-action" title="Supprimer"><?= icon('trash') ?></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php include '../includes/footer.php'; ?>
    
    <script>
        function previewImage(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('image-preview');
                    const previewImg = document.getElementById('preview-img');
                    previewImg.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        }
        
        function addVariant() {
            const container = document.getElementById('variants-container');
            const div = document.createElement('div');
            div.className = 'variant-row';
            div.style.cssText = 'display: flex; gap: 10px; margin-bottom: 10px;';
            div.innerHTML = `
                <input type="text" name="variant_names[]" placeholder="Ex: Taille M" style="flex: 2;">
                <input type="text" name="variant_skus[]" placeholder="SKU (optionnel)" style="flex: 2;">
                <input type="number" name="variant_stocks[]" placeholder="Stock" min="0" value="0" style="flex: 1;">
                <button type="button" onclick="this.parentElement.remove()" class="btn btn-danger btn-sm">×</button>
            `;
            container.appendChild(div);
        }
    </script>
</body>
</html>
