<?php
require_once 'config/database.php';
require_once 'config/session.php';

$product_id = $_GET['id'] ?? 0;

// Récupérer le produit
$stmt = $pdo->prepare("
    SELECT p.*, c.name as category_name, c.slug as category_slug
    FROM shop_products p
    LEFT JOIN shop_categories c ON p.category_id = c.id
    WHERE p.id = ? AND p.is_active = 1
");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: shop.php');
    exit;
}

// Récupérer les images du produit
$stmt = $pdo->prepare("SELECT * FROM shop_product_images WHERE product_id = ? ORDER BY id ASC");
$stmt->execute([$product_id]);
$images = $stmt->fetchAll();

// Récupérer les variantes
$stmt = $pdo->prepare("SELECT * FROM shop_product_variants WHERE product_id = ? ORDER BY id ASC");
$stmt->execute([$product_id]);
$variants = $stmt->fetchAll();

// Ajouter au panier
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $variant_id = $_POST['variant_id'] ?? null;
    $quantity = (int)($_POST['quantity'] ?? 1);
    
    // Vérifier le stock
    $stock_ok = true;
    if ($product['stock_management']) {
        if ($variant_id) {
            $stmt = $pdo->prepare("SELECT stock_quantity FROM shop_product_variants WHERE id = ?");
            $stmt->execute([$variant_id]);
            $variant = $stmt->fetch();
            $stock_ok = $variant && $variant['stock_quantity'] >= $quantity;
        } else {
            $stock_ok = $product['stock_quantity'] >= $quantity;
        }
    }
    
    if ($stock_ok) {
        // Si utilisateur connecté, sauvegarder en base
        if (isset($_SESSION['user_id'])) {
            // Vérifier si l'article existe déjà
            $stmt = $pdo->prepare("
                SELECT id, quantity FROM shop_cart 
                WHERE user_id = ? AND product_id = ? AND (variant_id = ? OR (variant_id IS NULL AND ? IS NULL))
            ");
            $stmt->execute([$_SESSION['user_id'], $product_id, $variant_id, $variant_id]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                // Mettre à jour la quantité
                $stmt = $pdo->prepare("UPDATE shop_cart SET quantity = quantity + ? WHERE id = ?");
                $stmt->execute([$quantity, $existing['id']]);
            } else {
                // Insérer un nouvel article
                $stmt = $pdo->prepare("
                    INSERT INTO shop_cart (user_id, product_id, variant_id, quantity) 
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([$_SESSION['user_id'], $product_id, $variant_id, $quantity]);
            }
        } else {
            // Sinon, utiliser la session
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }
            
            $cart_key = $product_id . '_' . ($variant_id ?? 0);
            if (isset($_SESSION['cart'][$cart_key])) {
                $_SESSION['cart'][$cart_key]['quantity'] += $quantity;
            } else {
                $_SESSION['cart'][$cart_key] = [
                    'product_id' => $product_id,
                    'variant_id' => $variant_id,
                    'quantity' => $quantity
                ];
            }
        }
        
        $_SESSION['success_message'] = "Produit ajouté au panier !";
        header('Location: cart.php');
        exit;
    } else {
        $error = "Stock insuffisant pour cette quantité.";
    }
}

// Image principale (featured ou première image)
$main_image = $product['featured_image'];
if (empty($main_image) && !empty($images)) {
    $main_image = $images[0]['image_url'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['name']) ?> - Boutique MAT</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/shop.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="container page-content">
        <nav class="breadcrumb">
            <a href="shop.php">Boutique</a> › 
            <?php if ($product['category_name']): ?>
                <a href="shop.php?category=<?= $product['category_slug'] ?>"><?= htmlspecialchars($product['category_name']) ?></a> › 
            <?php endif; ?>
            <span><?= htmlspecialchars($product['name']) ?></span>
        </nav>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <div class="product-detail">
            <!-- Galerie d'images -->
            <div class="product-gallery">
                <div class="main-image">
                    <?php if ($main_image): ?>
                        <img id="mainProductImage" src="<?= htmlspecialchars($main_image) ?>" 
                             alt="<?= htmlspecialchars($product['name']) ?>">
                    <?php else: ?>
                        <div class="image-placeholder">
                            <?= icon('image') ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($images)): ?>
                    <div class="image-thumbnails">
                        <?php foreach ($images as $img): ?>
                            <img src="<?= htmlspecialchars($img['image_url']) ?>" 
                                 alt="<?= htmlspecialchars($img['alt_text'] ?? $product['name']) ?>"
                                 onclick="changeMainImage('<?= htmlspecialchars($img['image_url']) ?>')"
                                 class="thumbnail">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Informations produit -->
            <div class="product-details-info">
                <div class="product-header">
                    <?php if ($product['category_name']): ?>
                        <span class="product-category"><?= htmlspecialchars($product['category_name']) ?></span>
                    <?php endif; ?>
                    <h1><?= htmlspecialchars($product['name']) ?></h1>
                </div>

                <div class="product-price-section">
                    <p class="product-price-large"><?= number_format($product['price'], 2) ?> €</p>
                    
                    <?php if ($product['stock_management']): ?>
                        <?php if ($product['stock_quantity'] > 0): ?>
                            <span class="stock-badge in-stock">✓ En stock</span>
                        <?php elseif ($product['stock_quantity'] <= 5 && $product['stock_quantity'] > 0): ?>
                            <span class="stock-badge low-stock">⚠ Stock faible (<?= $product['stock_quantity'] ?> restants)</span>
                        <?php else: ?>
                            <span class="stock-badge out-of-stock">✗ Rupture de stock</span>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <div class="product-description">
                    <?= nl2br(htmlspecialchars($product['description'])) ?>
                </div>

                <!-- Formulaire d'ajout au panier -->
                <form method="POST" class="add-to-cart-form">
                    <?php if (!empty($variants)): ?>
                        <div class="form-group">
                            <label>Choisir une option :</label>
                            <select name="variant_id" id="variantSelect" required onchange="updateStock()">
                                <option value="">-- Sélectionner --</option>
                                <?php foreach ($variants as $variant): ?>
                                    <?php 
                                    $available = !$product['stock_management'] || $variant['stock_quantity'] > 0;
                                    ?>
                                    <option value="<?= $variant['id'] ?>" 
                                            data-stock="<?= $variant['stock_quantity'] ?>"
                                            data-sku="<?= htmlspecialchars($variant['sku']) ?>"
                                            <?= !$available ? 'disabled' : '' ?>>
                                        <?= htmlspecialchars($variant['variant_name']) ?>
                                        <?= !$available ? ' (Rupture)' : '' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="quantity">Quantité :</label>
                        <input type="number" name="quantity" id="quantity" value="1" min="1" 
                               max="<?= $product['stock_management'] ? $product['stock_quantity'] : 99 ?>" required>
                        <span id="stockInfo"></span>
                    </div>

                    <?php 
                    $can_add = !$product['stock_management'] || $product['stock_quantity'] > 0;
                    if (!empty($variants)) {
                        $can_add = true; // On vérifie au niveau des variantes
                    }
                    ?>
                    
                    <button type="submit" name="add_to_cart" class="btn btn-primary btn-large" 
                            <?= !$can_add ? 'disabled' : '' ?>>
                        <?= icon('shopping-cart') ?> Ajouter au panier
                    </button>
                </form>

                <?php if (!empty($product['sku'])): ?>
                    <p class="product-sku">Référence : <?= htmlspecialchars($product['sku']) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script>
        function changeMainImage(url) {
            document.getElementById('mainProductImage').src = url;
        }

        function updateStock() {
            const select = document.getElementById('variantSelect');
            const quantityInput = document.getElementById('quantity');
            const stockInfo = document.getElementById('stockInfo');
            
            if (select && select.value) {
                const option = select.options[select.selectedIndex];
                const stock = parseInt(option.dataset.stock);
                
                if (stock > 0) {
                    quantityInput.max = stock;
                    stockInfo.textContent = `(${stock} disponible${stock > 1 ? 's' : ''})`;
                    stockInfo.className = 'stock-info';
                } else {
                    quantityInput.max = 0;
                    stockInfo.textContent = '(Rupture de stock)';
                    stockInfo.className = 'stock-info out';
                }
            }
        }
    </script>
</body>
</html>
