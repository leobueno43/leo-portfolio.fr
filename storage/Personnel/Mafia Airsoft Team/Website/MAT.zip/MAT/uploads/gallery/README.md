# Instructions pour créer le favicon.ico

Placez votre fichier favicon.ico ici : `images/favicon.ico`

Le code a déjà été ajouté dans tous les fichiers PHP.
