# 📸 Système de Galerie Photo - Guide d'utilisation

## Installation

### 1. Créer la table dans la base de données
Exécutez le fichier SQL dans phpMyAdmin :
```bash
localhost/phpmyadmin
```
Puis importez ou exécutez : `database/gallery_table.sql`

### 2. Vérifier les permissions du dossier
Le dossier `uploads/gallery/` doit être accessible en écriture.

## Utilisation Admin

### Accéder à la gestion
1. Connectez-vous en tant qu'admin
2. Allez sur le Dashboard Admin
3. Cliquez sur **"Gérer la galerie photo"**
4. URL directe : `localhost/MAT/admin/manage_gallery.php`

### Ajouter une photo
1. Cliquez sur "Choisir un fichier"
2. Sélectionnez une image (JPG, PNG, WEBP - Max 5MB)
3. Optionnel : Ajoutez un titre et une description
4. Définissez l'ordre d'affichage (0 = première photo)
5. Cliquez sur "Ajouter la photo"

### Gérer les photos
- **Afficher/Masquer** : Cliquez sur le bouton "👁️ Afficher" ou "👁️ Masquer"
- **Modifier l'ordre** : Changez le numéro et cliquez sur "↕️"
- **Supprimer** : Cliquez sur "🗑️ Supprimer" (confirmation requise)

### Ordre d'affichage
- 0, 1, 2, 3... : Les photos avec les numéros les plus bas apparaissent en premier
- Si plusieurs photos ont le même ordre, elles sont triées par date de création

## Affichage sur le site

### Page d'accueil (index.php)
Le carrousel s'affiche automatiquement si des photos actives existent :
- **Autoplay** : Change automatiquement toutes les 5 secondes
- **Navigation manuelle** : Flèches gauche/droite ou points en bas
- **Pause au survol** : Le carrousel se met en pause quand la souris passe dessus
- **Touch/Swipe** : Glissez sur mobile pour naviguer

### Caractéristiques techniques
- ✅ Rotation automatique (5 secondes par photo)
- ✅ Navigation par flèches (← →)
- ✅ Navigation par points (● ● ●)
- ✅ Pause au survol
- ✅ Responsive (adapté mobile/tablette/desktop)
- ✅ Support touch/swipe sur mobile
- ✅ Affichage du titre et description en overlay
- ✅ Design tactique cohérent (rouge/noir)

## Recommandations photos

### Format
- **Ratio recommandé** : 16:9 (1920x1080px ou 1280x720px)
- **Formats acceptés** : JPG, PNG, WEBP
- **Poids maximum** : 5MB par photo
- **Optimisation** : Compressez vos images avant upload pour de meilleures performances

### Contenu suggéré
- Photos de parties en action
- Terrain de jeu
- Équipe en tenue tactique
- Équipements
- Ambiance des événements
- Photos de groupe

## Styles CSS appliqués

### Carrousel
- Container : Bordure rouge tactique, fond noir
- Images : Ratio 16:9 (desktop), 4:3 (mobile)
- Caption : Overlay gradient noir, texte rouge/blanc
- Boutons : Ronds rouges avec effet glow au survol
- Dots : Points rouges avec effet scale au clic

### Admin
- Grid responsive : 3 colonnes (desktop) → 1 colonne (mobile)
- Cards : Fond dégradé noir, bordure rouge
- Inactive overlay : Badge "DÉSACTIVÉE" en overlay
- Actions : Boutons compacts alignés

## Fichiers concernés

### Frontend
- `index.php` - Affichage du carrousel
- `css/style.css` - Styles du carrousel et admin gallery
- `js/gallery.js` - Logique du carrousel (autoplay, navigation, swipe)

### Backend
- `admin/manage_gallery.php` - Interface de gestion admin
- `database/gallery_table.sql` - Schéma de la table
- `uploads/gallery/` - Dossier de stockage des photos

### Base de données
Table `gallery` :
- `id` : Identifiant unique
- `image_path` : Chemin relatif de l'image
- `title` : Titre (optionnel)
- `description` : Description (optionnel)
- `display_order` : Ordre d'affichage (0, 1, 2...)
- `is_active` : Actif/Inactif (1/0)
- `created_at` : Date de création
- `updated_at` : Date de modification

## Troubleshooting

### La galerie ne s'affiche pas
1. Vérifiez que la table `gallery` existe
2. Vérifiez qu'il y a au moins une photo avec `is_active = 1`
3. Vérifiez le chemin des images dans la BDD

### Erreur d'upload
1. Vérifiez les permissions du dossier `uploads/gallery/` (chmod 755 ou 777)
2. Vérifiez la taille du fichier (max 5MB)
3. Vérifiez le format (JPG, PNG, WEBP seulement)

### Le carrousel ne fonctionne pas
1. Vérifiez que `js/gallery.js` est bien chargé
2. Ouvrez la console du navigateur (F12) pour voir les erreurs JavaScript
3. Vérifiez qu'il y a au moins 2 photos pour activer la navigation

## Futures améliorations possibles
- [ ] Upload multiple de photos
- [ ] Édition des titres/descriptions existants
- [ ] Redimensionnement automatique des images
- [ ] Réorganisation par drag & drop
- [ ] Galerie par événement (associer photos aux parties)
- [ ] Lightbox au clic sur les photos
- [ ] Statistiques de vues
