<?php
require_once 'config/database.php';
require_once 'config/session.php';

$slug = $_GET['slug'] ?? '';

// Récupérer l'article
$stmt = $pdo->prepare("
    SELECT bp.*, u.pseudo as author_name, u.profile_picture as author_picture
    FROM blog_posts bp
    JOIN users u ON bp.author_id = u.id
    WHERE bp.slug = ? AND bp.is_published = 1
");
$stmt->execute([$slug]);
$post = $stmt->fetch();

if (!$post) {
    header('Location: blog.php');
    exit;
}

// Incrémenter le compteur de vues
$stmt = $pdo->prepare("UPDATE blog_posts SET views = views + 1 WHERE id = ?");
$stmt->execute([$post['id']]);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($post['title']) ?> - Blog Mafia Airsoft Team</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="container page-content">
        <div class="blog-post-header">
            <a href="blog.php" class="btn btn-outline">← Retour au blog</a>
        </div>

        <article class="blog-post">
            <?php if ($post['featured_image']): ?>
                <div class="blog-post-image">
                    <img src="<?= htmlspecialchars($post['featured_image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>">
                </div>
            <?php endif; ?>
            
            <div class="blog-post-meta">
                <div class="author-info">
                    <?php if ($post['author_picture']): ?>
                        <img src="<?= htmlspecialchars($post['author_picture']) ?>" alt="<?= htmlspecialchars($post['author_name']) ?>" class="author-avatar">
                    <?php else: ?>
                        <div class="author-avatar"><?= icon('user') ?></div>
                    <?php endif; ?>
                    <div>
                        <strong><?= htmlspecialchars($post['author_name']) ?></strong>
                        <span class="blog-date">
                            Publié le <?= date('d/m/Y à H:i', strtotime($post['published_at'])) ?>
                        </span>
                    </div>
                </div>
                <span class="blog-views"><?= icon('eye') ?> <?= $post['views'] + 1 ?> vues</span>
            </div>

            <h1 class="blog-post-title"><?= htmlspecialchars($post['title']) ?></h1>

            <div class="blog-post-content">
                <?= nl2br(htmlspecialchars($post['content'])) ?>
            </div>

            <div class="blog-post-footer">
                <a href="blog.php" class="btn btn-primary">← Retour au blog</a>
            </div>
        </article>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
