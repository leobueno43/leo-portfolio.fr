# Système d'Icônes - Mafia Airsoft Team

## 📁 Dossier des icônes
`images/icons/`

## 🎨 Format requis
- **Format:** PNG transparent
- **Taille:** 24x24 pixels
- **Style:** Noir/Gris/Rouge (selon le logo)

## 📋 Liste des icônes nécessaires

### Navigation & Interface
1. **home.png** - 🏠 Accueil
2. **calendar.png** - 📅 Agenda/Date
3. **user.png** - 👤 Utilisateur/Avatar
4. **edit.png** - 📝 Édition/Blog
5. **logout.png** - 🚪 Déconnexion
6. **settings.png** - ⚙️ Administration
7. **eye.png** - 👁️ Voir/Vues
8. **arrow-left.png** - 🔙 Retour

### Actions
9. **plus.png** - ➕ Ajouter/Créer
10. **trash.png** - 🗑️ Supprimer
11. **check.png** - ✅ Confirmation

### Contenu
12. **target.png** - 🎯 Objectifs/Parties
13. **users.png** - 👥 Équipe/Joueurs
14. **stats.png** - 📊 Statistiques
15. **list.png** - 📋 Liste/Description
16. **alert.png** - ⚠️ Avertissement
17. **gun.png** - 🔫 Arme/Style de jeu

## 🔄 Fonctionnement automatique

Le système détecte automatiquement les icônes dans le dossier `images/icons/`.

### Pour ajouter une nouvelle icône:
1. Créer l'icône au format PNG 24x24px
2. Nommer le fichier selon la liste ci-dessus (ex: `user.png`)
3. Placer le fichier dans `c:\xampp\htdocs\MAT\images\icons\`
4. L'icône s'affiche automatiquement partout où elle est utilisée

### Si l'icône n'existe pas:
- Rien ne s'affiche (emoji retiré proprement)
- Pas d'erreur PHP

## 💻 Utilisation dans le code

Tous les emojis ont été remplacés par des appels à la fonction `icon()`:

```php
// Ancien code avec emoji
<h1>👤 Mon espace</h1>

// Nouveau code avec icône
<h1><?= icon('user') ?> Mon espace</h1>
```

## 🎯 Emplacements des icônes

### Fichiers principaux
- `includes/header.php` - user
- `index.php` - target, gun, users, alert
- `events.php` - calendar, target
- `event.php` - calendar, check, list, target, users, user (avatars)
- `blog.php` - edit, user, calendar, eye
- `blog_post.php` - user, eye
- `player/dashboard.php` - user, edit, stats, target, calendar, users

### Fichiers admin
- `admin/index.php` - settings, stats, plus, users, calendar, eye, edit, trash
- `admin/manage_blog.php` - edit, plus, eye, trash
- `admin/players.php` - users, plus, user, target
- `admin/view_event.php` - eye, edit, list, stats, users, trash
- `admin/create_event.php` - plus
- `admin/edit_event.php` - edit
- `admin/delete_event.php` - alert, trash

## ✅ État actuel

✅ Fonction `icon()` créée dans `includes/icons.php`
✅ Dossier `images/icons/` créé
✅ Tous les emojis remplacés dans tous les fichiers PHP
✅ CSS ajouté pour l'alignement et le dimensionnement des icônes
✅ Système prêt à recevoir les icônes PNG

🔴 **Action requise:** Placer les 17 fichiers PNG d'icônes dans `images/icons/`
