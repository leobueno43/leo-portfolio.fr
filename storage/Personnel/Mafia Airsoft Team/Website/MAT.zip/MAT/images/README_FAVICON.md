# Générer le favicon

Pour créer le fichier `favicon.ico` à partir de votre logo :

## Option 1 : Utiliser un convertisseur en ligne
1. Allez sur https://www.favicon-generator.org/ ou https://favicon.io/
2. Uploadez votre fichier `logo.png`
3. Téléchargez le fichier `favicon.ico` généré
4. Placez-le dans le dossier `images/`

## Option 2 : Utiliser ImageMagick (en ligne de commande)
```bash
# Installer ImageMagick si nécessaire
# Puis exécuter :
convert logo.png -define icon:auto-resize=64,48,32,16 favicon.ico
```

## Option 3 : Utiliser GIMP
1. Ouvrir `logo.png` avec GIMP
2. Redimensionner l'image à 32x32 pixels (Image > Échelle et taille de l'image)
3. Exporter en tant que `favicon.ico` (Fichier > Exporter sous)
4. Placez-le dans le dossier `images/`

Le fichier `favicon.ico` doit être placé dans : `c:\xampp\htdocs\MAT\images\favicon.ico`

Les liens ont déjà été ajoutés dans tous les fichiers PHP du site.
