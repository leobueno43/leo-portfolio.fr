<?php
require_once '../config/database.php';
require_once '../config/session.php';
requireAdmin();

$message = '';
$error = '';
$edit_post = null;

// Récupérer l'article à éditer
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM blog_posts WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_post = $stmt->fetch();
}

// Gérer la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'update') {
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $excerpt = trim($_POST['excerpt'] ?? '');
        $featured_image = trim($_POST['featured_image'] ?? '');
        $is_published = isset($_POST['is_published']) ? 1 : 0;
        
        // Générer le slug
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        
        if (empty($title) || empty($content)) {
            $error = 'Le titre et le contenu sont obligatoires.';
        } else {
            if ($action === 'create') {
                $published_at = $is_published ? date('Y-m-d H:i:s') : null;
                $stmt = $pdo->prepare("
                    INSERT INTO blog_posts (title, slug, content, excerpt, featured_image, author_id, is_published, published_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                if ($stmt->execute([$title, $slug, $content, $excerpt, $featured_image, $_SESSION['user_id'], $is_published, $published_at])) {
                    $message = 'Article créé avec succès !';
                } else {
                    $error = 'Erreur lors de la création.';
                }
            } else {
                $post_id = $_POST['post_id'];
                $published_at = $is_published && !$edit_post['is_published'] ? date('Y-m-d H:i:s') : $edit_post['published_at'];
                
                $stmt = $pdo->prepare("
                    UPDATE blog_posts 
                    SET title = ?, slug = ?, content = ?, excerpt = ?, featured_image = ?, is_published = ?, published_at = ?
                    WHERE id = ?
                ");
                if ($stmt->execute([$title, $slug, $content, $excerpt, $featured_image, $is_published, $published_at, $post_id])) {
                    $message = 'Article mis à jour !';
                    $edit_post = null;
                } else {
                    $error = 'Erreur lors de la mise à jour.';
                }
            }
        }
    } elseif ($action === 'delete') {
        $post_id = $_POST['post_id'];
        $stmt = $pdo->prepare("DELETE FROM blog_posts WHERE id = ?");
        if ($stmt->execute([$post_id])) {
            $message = 'Article supprimé !';
        }
    }
}

// Récupérer tous les articles
$stmt = $pdo->query("
    SELECT bp.*, u.pseudo as author_name
    FROM blog_posts bp
    JOIN users u ON bp.author_id = u.id
    ORDER BY bp.created_at DESC
");
$posts = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion du Blog - Administration</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container page-content">
        <h1><?= icon('edit') ?> Gestion du Blog</h1>

        <?php if ($message): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Formulaire de création/édition -->
        <section class="admin-section">
            <h2><?= $edit_post ? icon('edit') . ' Modifier l\'article' : icon('plus') . ' Nouvel article' ?></h2>
            <form method="POST" class="admin-form">
                <input type="hidden" name="action" value="<?= $edit_post ? 'update' : 'create' ?>">
                <?php if ($edit_post): ?>
                    <input type="hidden" name="post_id" value="<?= $edit_post['id'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label for="title">Titre *</label>
                    <input type="text" id="title" name="title" required 
                           value="<?= htmlspecialchars($edit_post['title'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="excerpt">Extrait (résumé court)</label>
                    <textarea id="excerpt" name="excerpt" rows="3"><?= htmlspecialchars($edit_post['excerpt'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label for="content">Contenu *</label>
                    <textarea id="content" name="content" rows="15" required><?= htmlspecialchars($edit_post['content'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label for="featured_image">URL de l'image (optionnel)</label>
                    <input type="url" id="featured_image" name="featured_image" 
                           value="<?= htmlspecialchars($edit_post['featured_image'] ?? '') ?>"
                           placeholder="https://exemple.com/image.jpg">
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_published" 
                               <?= ($edit_post['is_published'] ?? 0) ? 'checked' : '' ?>>
                        Publier l'article
                    </label>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <?= $edit_post ? 'Mettre à jour' : 'Créer l\'article' ?>
                    </button>
                    <?php if ($edit_post): ?>
                        <a href="manage_blog.php" class="btn btn-secondary">Annuler</a>
                    <?php endif; ?>
                </div>
            </form>
        </section>

        <!-- Liste des articles -->
        <section class="admin-section">
            <h2>📚 Tous les articles</h2>
            <?php if (empty($posts)): ?>
                <p class="no-data">Aucun article créé.</p>
            <?php else: ?>
                <div class="admin-table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Titre</th>
                                <th>Auteur</th>
                                <th>Date</th>
                                <th>Vues</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($posts as $post): ?>
                                <tr>
                                    <td><?= $post['id'] ?></td>
                                    <td><strong><?= htmlspecialchars($post['title']) ?></strong></td>
                                    <td><?= htmlspecialchars($post['author_name']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($post['created_at'])) ?></td>
                                    <td><?= $post['views'] ?></td>
                                    <td>
                                        <?php if ($post['is_published']): ?>
                                            <span class="badge badge-success">Publié</span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">Brouillon</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="table-actions">
                                        <?php if ($post['is_published']): ?>
                                            <a href="../blog_post.php?slug=<?= $post['slug'] ?>" class="btn-action" target="_blank" title="Voir"><?= icon('eye') ?></a>
                                        <?php endif; ?>
                                        <a href="?edit=<?= $post['id'] ?>" class="btn-action" title="Modifier"><?= icon('edit') ?></a>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Supprimer cet article ?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                                            <button type="submit" class="btn-action" title="Supprimer"><?= icon('trash') ?></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php include '../includes/footer.php'; ?>
</body>
</html>
