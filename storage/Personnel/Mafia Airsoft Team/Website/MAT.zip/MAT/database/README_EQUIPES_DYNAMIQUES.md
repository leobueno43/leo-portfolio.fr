# Système d'Équipes Dynamiques - Guide d'utilisation

## 📋 Vue d'ensemble

Le système d'équipes dynamiques permet de personnaliser entièrement les équipes pour chaque partie :
- **Noms personnalisés** : Plus limité à "Bleu", "Rouge", etc.
- **Couleurs au choix** : Choisissez n'importe quelle couleur pour chaque équipe
- **Nombre flexible** : Ajoutez autant d'équipes que nécessaire
- **Limites ajustables** : Définissez le nombre maximum de joueurs par équipe

## 🚀 Installation

### 1. Exécuter la mise à jour de la base de données

Connectez-vous à phpMyAdmin ou à votre client MySQL et exécutez le fichier :
```
database/update_dynamic_teams.sql
```

Cette mise à jour :
- Crée la table `event_teams` pour les équipes personnalisées
- Modifie la table `registrations` pour supporter les clés d'équipe flexibles
- Supprime les anciennes colonnes `max_players_*` de la table `events`
- Migre les événements existants vers le nouveau système avec 3 équipes par défaut

### 2. Vérification

Après l'exécution du script SQL, vérifiez que :
- La table `event_teams` existe
- Vos événements existants ont des équipes dans `event_teams`
- La table `registrations` accepte maintenant des valeurs VARCHAR pour la colonne `team`

## 📖 Utilisation

### Créer une nouvelle partie

1. Allez dans **Admin > Créer une nouvelle partie**
2. Remplissez les informations de base (titre, date, lieu, scénario, etc.)
3. Cliquez sur **"Créer la partie"**
4. Vous serez automatiquement redirigé vers **"Gérer les équipes"**
5. Par défaut, 3 équipes sont créées :
   - 🔵 Équipe Bleue (15 joueurs max)
   - 🔴 Équipe Rouge (15 joueurs max)
   - ⚪ Organisation (3 joueurs max)

### Gérer les équipes d'une partie existante

1. Allez dans **Admin > Gestion des parties**
2. Cliquez sur "Modifier" pour une partie
3. Cliquez sur le bouton **"Gérer les équipes"**

### Ajouter une équipe

1. Dans la page "Gérer les équipes"
2. Remplissez le formulaire "Ajouter une équipe" :
   - **Clé** : Identifiant unique (ex: GREEN, YELLOW, MEDIC)
     - Uniquement lettres majuscules, chiffres et underscore
     - Doit être unique pour cet événement
   - **Nom** : Nom affiché (ex: "Équipe Verte", "Médics")
   - **Couleur** : Sélectionnez la couleur de l'équipe
   - **Nombre max** : Limite de joueurs pour cette équipe

3. Cliquez sur **"Ajouter l'équipe"**

### Modifier une équipe

1. Cliquez sur le bouton **"Modifier"** à côté de l'équipe
2. Modifiez le nom, la couleur ou la limite de joueurs
3. Cliquez sur **"Enregistrer"**

**Note** : La clé de l'équipe ne peut pas être modifiée après création.

### Supprimer une équipe

1. Cliquez sur le bouton **"Supprimer"** à côté de l'équipe
2. Confirmez la suppression

**⚠️ Important** : Vous ne pouvez pas supprimer une équipe si des joueurs y sont déjà inscrits.

### Réorganiser les équipes

1. Modifiez les numéros d'ordre dans les champs à côté de chaque équipe
2. Cliquez sur **"Enregistrer l'ordre d'affichage"**

Les équipes seront affichées dans l'ordre croissant lors des inscriptions.

## 🎨 Exemples de configurations

### Partie classique (2 équipes)
- **BLUE** : Équipe Bleue (#3b82f6) - 20 joueurs
- **RED** : Équipe Rouge (#dc2626) - 20 joueurs

### Partie multi-équipes
- **ALPHA** : Équipe Alpha (#3b82f6) - 10 joueurs
- **BRAVO** : Équipe Bravo (#10b981) - 10 joueurs
- **CHARLIE** : Équipe Charlie (#f59e0b) - 10 joueurs
- **DELTA** : Équipe Delta (#8b5cf6) - 10 joueurs

### Partie avec rôles spéciaux
- **ATTACK** : Attaquants (#dc2626) - 15 joueurs
- **DEFENSE** : Défenseurs (#3b82f6) - 15 joueurs
- **SNIPER** : Snipers (#6b7280) - 4 joueurs
- **MEDIC** : Médics (#10b981) - 3 joueurs
- **ORGA** : Organisation (#a3a3a3) - 3 joueurs

### Partie thématique (Zombies)
- **HUMANS** : Survivants (#10b981) - 25 joueurs
- **ZOMBIES** : Zombies (#dc2626) - 15 joueurs
- **ORGA** : Organisation (#a3a3a3) - 5 joueurs

## 🔧 Intégration technique

### Récupérer les équipes d'un événement (PHP)

```php
$stmt = $pdo->prepare("
    SELECT et.*,
           (SELECT COUNT(*) FROM registrations 
            WHERE event_id = et.event_id AND team = et.team_key) as current_players
    FROM event_teams et
    WHERE et.event_id = ?
    ORDER BY et.display_order ASC
");
$stmt->execute([$event_id]);
$teams = $stmt->fetchAll();
```

### Vérifier la disponibilité d'une équipe

```php
$stmt = $pdo->prepare("
    SELECT et.max_players,
           (SELECT COUNT(*) FROM registrations 
            WHERE event_id = et.event_id AND team = et.team_key) as current_players
    FROM event_teams et
    WHERE et.event_id = ? AND et.team_key = ?
");
$stmt->execute([$event_id, $team_key]);
$team = $stmt->fetch();

$is_full = ($team['current_players'] >= $team['max_players']);
```

### Afficher les équipes avec leurs couleurs (HTML/CSS)

```php
<?php foreach ($teams as $team): ?>
    <div class="team-option" style="border-left: 4px solid <?= $team['team_color'] ?>">
        <h3><?= htmlspecialchars($team['team_name']) ?></h3>
        <p><?= $team['current_players'] ?> / <?= $team['max_players'] ?> joueurs</p>
    </div>
<?php endforeach; ?>
```

## 📊 Structure de la base de données

### Table `event_teams`

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | Identifiant unique |
| event_id | INT | ID de l'événement |
| team_key | VARCHAR(50) | Clé unique de l'équipe (ex: BLUE) |
| team_name | VARCHAR(100) | Nom affiché de l'équipe |
| team_color | VARCHAR(7) | Couleur hexadécimale (#RRGGBB) |
| max_players | INT | Nombre maximum de joueurs |
| display_order | INT | Ordre d'affichage |
| created_at | TIMESTAMP | Date de création |

### Table `registrations` (modifiée)

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | Identifiant unique |
| user_id | INT | ID du joueur |
| event_id | INT | ID de l'événement |
| team | VARCHAR(50) | Clé de l'équipe (référence team_key) |
| notes | TEXT | Notes du joueur |
| registered_at | TIMESTAMP | Date d'inscription |

## ⚠️ Notes importantes

1. **Migration automatique** : Les événements existants sont migrés automatiquement avec les équipes BLUE, RED et ORGA
2. **Clés uniques** : Chaque team_key doit être unique par événement
3. **Suppression en cascade** : Supprimer un événement supprime automatiquement toutes ses équipes
4. **Protection des inscriptions** : Impossible de supprimer une équipe avec des joueurs inscrits
5. **Couleurs hexadécimales** : Format #RRGGBB obligatoire pour les couleurs

## 🐛 Dépannage

### Erreur : "Duplicate entry for key 'unique_team_per_event'"
- La clé d'équipe existe déjà pour cet événement
- Choisissez une clé différente

### Erreur : "Cannot delete team - players are registered"
- Des joueurs sont inscrits dans cette équipe
- Déplacez-les vers une autre équipe ou supprimez leurs inscriptions d'abord

### Les couleurs ne s'affichent pas
- Vérifiez que le format de couleur est bien #RRGGBB
- Assurez-vous d'avoir vidé le cache du navigateur

## 📞 Support

Pour toute question ou problème, contactez l'administrateur système.
