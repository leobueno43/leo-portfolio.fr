﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NexusSecours.Models.DTOs
{
    internal class LoginRequest
    {
    }
}
