﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NexusSecours.Desktop.ViewModels
{
    internal class MceViewModel
    {
    }
}
