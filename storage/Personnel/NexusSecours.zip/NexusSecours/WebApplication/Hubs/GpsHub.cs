﻿namespace NexusSecours.API.Hubs
{
    public class GpsHub
    {
    }
}
