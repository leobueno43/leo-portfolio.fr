﻿namespace NexusSecours.API.Hubs
{
    public class MceHub
    {
    }
}
