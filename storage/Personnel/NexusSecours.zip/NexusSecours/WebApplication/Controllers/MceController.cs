﻿namespace NexusSecours.API.Controllers
{
    public class MceController
    {
    }
}
