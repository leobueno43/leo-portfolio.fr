﻿namespace NexusSecours.API.Controllers
{
    public class AuthController
    {
    }
}
