﻿namespace NexusSecours.API.Data
{
    public class NexusDbContext
    {
    }
}
