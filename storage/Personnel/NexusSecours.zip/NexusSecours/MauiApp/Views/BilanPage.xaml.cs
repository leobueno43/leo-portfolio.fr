namespace MauiApp.Views;

public partial class BilanPage : ContentPage
{
	public BilanPage()
	{
		InitializeComponent();
	}
}